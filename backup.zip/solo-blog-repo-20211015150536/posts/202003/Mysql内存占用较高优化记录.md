title: Mysql内存占用较高优化记录
date: '2020-03-17 17:08:33'
updated: '2020-03-17 17:08:33'
tags: [mysql]
permalink: /articles/2020/03/17/1584436112951.html
---
![](https://img.hacpai.com/bing/20180828.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

服务器是阿里云 1 核 1G 的，运行了一个 mysql,一个 solo,一个 docker，发现内存占用高达 90%

通过命令：
ps -auxf | sort -nr -k 4 | head -10

查找到内存占用前十的程序：

![](https://img.hacpai.com/file/2020/03/图片-e4e47bcb.png "图片.png")

不得不说看到 MySQL 占用内存这么高，还是有点蒙圈。

优化过程：修改 MySQL 配置文件。在 etc/my.cnf 当中找到或者添加下列参数

```
innodb_buffer_pool_size =64M
key_buffer_size =32M
tmp_table_size = 64M 
table_open_cache=512
```

参数的具体设置主要参考下面两篇文章
参考文章 1：https://blog.csdn.net/dc666/article/details/78901341
参考文章 2：https://www.cnblogs.com/chenking/p/10861203.html

最后输入命令重启 MySQL  ：mysqld restart
查看效果：嗯，还是不错的。

![](https://img.hacpai.com/file/2020/03/图片-ccf981a2.png "图片.png") 
