title: Spring boot @Async注解导致Controller层在实现接口后，请求报404
date: '2021-08-02 15:53:39'
updated: '2021-08-02 15:53:39'
tags: [bug, springboot]
permalink: /articles/2021/08/02/1627890819400.html
---
![](https://b3logfile.com/bing/20190625.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

最近在使用fegin服务调用的时候，同事遇见一个非常困扰的问题，在controller层正常实现fegin接口后，发现无法正常调用服务。
觉得挺好奇的，特此记录一下问题原因和处理方式

原因：在controller层有个方法上面有@Async 注解导致的，（如果不实现接口类，直接使用@Async  请求不会报404）
处理方式：将需要异步的代码放在service层处理！！！
这篇文章给出了问题详细的解释：https://www.cnblogs.com/ming-blogs/p/12951861.html

@Async 注解 使用注意事项

> 1. 没有在@SpringBootApplication启动类当中添加注解@EnableAsync注解。
> 2. 异步方法使用注解@Async的返回值只能为void或者Future。
> 3. 没有走Spring的代理类。（即ServiceA里面方法A调用方法B,会不生效！！） 方法一定要从另一个类中调用，也就是从类的外部调用，类的内部调用是无效的，需要先获取其代理类，通过代理类调用异步方法
>
