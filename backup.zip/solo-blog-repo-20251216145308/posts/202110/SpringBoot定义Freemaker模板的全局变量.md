title: SpringBoot定义Freemaker模板的全局变量
date: '2021-10-20 11:01:35'
updated: '2021-10-20 11:01:35'
tags: [springboot, freemaker]
permalink: /articles/2021/10/20/1634698895427.html
---
```java



import freemarker.template.Configuration;
import freemarker.template.TemplateModelException;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * freemarker配置
 *
 * @author hjljy
 * @date 2021/10/15
 */
@Component
public class FreemarkerConfiguration {

    private final Configuration configuration;

    public FreemarkerConfiguration(Configuration configuration) {
   
        this.configuration = configuration;
    }

    /**
     * 加载配置变量数据
     *
     * @throws TemplateModelException 模板模型异常
     */
    @PostConstruct
    public void loadConfig() throws TemplateModelException {

        configuration.setSharedVariable("name", "海加尔金鹰");

        configuration.setSharedVariable("url", "https://www.hjljy.cn");

    }


}

```
