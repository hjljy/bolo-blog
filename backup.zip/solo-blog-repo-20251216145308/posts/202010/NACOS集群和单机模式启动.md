title: NACOS集群和单机模式启动
date: '2020-10-30 18:58:31'
updated: '2021-09-26 09:38:18'
tags: [nacos]
permalink: /articles/2020/10/30/1604055510999.html
---
![](https://b3logfile.com/bing/20191109.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## NACOS下载

nacos官方下载非常慢，放在了百度云备份了一个
[nacos1.3.2版本下载（提取码：1234）](https://pan.baidu.com/s/1tA-EqcAwwtU60B4bugOgcQ)

## 单机模式启动

下载完毕后，解压，进入bin目录，找到startup.cmd。如果直接双击，默认是集群模式，启动会报错：db.num is null，Unable to start embedded Tomcat.......

处理方式一： 进入cmd 输入startup.cmd -m standalone即可成功启动
处理方式二：编辑startup.cmd启动命令，将set MODE="cluster" 变成set MODE="standalone" 然后双击即可

启动成功后，直接在浏览器输入http://127.0.0.1:8848/nacos/index.html 即可进入默认的nacos管理界面，账号密码默认都是nacos

## 集群模式启动

单机模式通常用于测试，或者简单使用，集群模式主要用于生产环境保证高可用。

### 第一步：

先准备三台机器，也可以在一天机器上部署三个，端口如下
···
127.0.0.1:8848
127.0.0.1:8858
127.0.0.1:8868
···

### 第二步：

准备一个mysql数据库，创建一个名为nacos的数据库，然后导入conf里面的nacos-mysql.sql文件，会自动创建相关表结构和数据。数据库也可以进行集群，读写分离等操作。

### 第三步：

复制三份nacos安装包，先修改conf里面的application.properties配置文件信息。先统一配置数据库链接信息，然后依次配置server.port端口为8848，8858，8868。

```

## Count of DB:
db.num=1
## Connect URL of DB:
db.url.0=jdbc:mysql://127.0.0.1:3306/nacos?characterEncoding=utf8&connectTimeout=1000&socketTimeout=3000&autoReconnect=true&useUnicode=true&useSSL=false&serverTimezone=UTC
db.user=root
db.password=123456
### Default web server port:
server.port=8848
```

然后找到三个nacos的conf里面的cluster.conf.example 复制一份，修改为cluster.conf，在里面配置集群信息
···
127.0.0.1:8848
127.0.0.1:8858
127.0.0.1:8868
···

### 第四步：

在启动了第一个nacos之后，无法启动第二个，发现报错：此时不应有logs\java_heapdump.hprof -XX:-UseLargePages
删除后面的startup.cmd里面的参数即可
-XX:HeapDumpPath=%BASE_DIR%\logs\java_heapdump.hprof -XX:-UseLargePages

### 第五步：

依次启动三个nacos,启动成功后就可以随便登录一个IP+端口就可以看到集群信息了。

![image.png](https://b3logfile.com/file/2020/10/image-5edc9acf.png)

## 总结

总的来说，下载和启动还是存在一些坑的，不过还是能够解决的。
