title: Springboot之Security整合注意问题
date: '2020-10-15 17:08:40'
updated: '2021-09-26 09:38:45'
tags: [Security]
permalink: /articles/2020/10/15/1602752919948.html
---
![](https://b3logfile.com/bing/20191029.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

之前简单实现了[Springboot之Security前后端分离登录](https://www.hjljy.cn/articles/2020/09/14/1600073738767.html)，在后续的使用当中发现了一些问题需要注意

## 1 登录后接口还是提示401的问题

由于我是直接调用登录接口，然后调用业务接口，发现业务接口401，原因是因为调用业务接口的时候cookies没有传登录接口的JSESSIONID,导致是新的链接请求。

## 2 业务接口加上注解没有效果

在controller层加上权限注解后，发现登录的账号没有权限也能访问
原因：WebSecurityConfiguration使用的是@EnableGlobalAuthentication注解，如需要进行方法级别的控制需要使用@EnableGlobalMethodSecurity(prePostEnabled = true,securedEnabled = true,jsr250Enabled = true)
[@EnableGlobalMethodSecurity三方法详解](https://www.jianshu.com/p/77b4835b6e8e)

## 3 添加角色控制方式

普通权限：
SimpleGrantedAuthority authority = new SimpleGrantedAuthority("sys:menu:add");
权限验证：
@PreAuthorize("hasAuthority('sys:menu:add')")

角色权限：
SimpleGrantedAuthority authority1 = new SimpleGrantedAuthority("ROLE_ADMIN");
权限验证：
@PreAuthorize("hasAnyRole('ADMIN')")
