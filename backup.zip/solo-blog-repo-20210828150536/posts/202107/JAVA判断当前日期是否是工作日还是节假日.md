title: JAVA判断当前日期是否是工作日，还是节假日
date: '2021-07-27 18:04:07'
updated: '2021-07-27 18:04:07'
tags: [待分类]
permalink: /articles/2021/07/27/1627380247688.html
---
![](https://b3logfile.com/bing/20180728.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

在使用hutool工具包的时候，发现hutool工具包无法判断是否是工作日还是节假日（因为每年节假日各不相同，所以自己写了一个）
当前只有2021年的数据，后续的数据需要等国务院发布
节假日数据来源：[国务院办公厅关于2021年部分节假日安排的通知](http://www.gov.cn/zhengce/content/2020-11/25/content_5564127.htm)

```java
package cn.hjljy.crawler.demo.holiday;

import com.sun.org.apache.xpath.internal.operations.Bool;

import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * 度假服务
 *
 * @author hjljy
 * @date 2021/07/27
 */
public class HolidayService {

    static List<String> holiday =new ArrayList<>();
    static List<String> extraWorkDay =new ArrayList<>();
    public static Boolean isWorkingDay(long time) {
        LocalDateTime dateTime = LocalDateTime.ofInstant(Instant.ofEpochMilli(time), ZoneOffset.of("+8"));
        String formatTime = dateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        initHoliday();
        initExtraWorkDay();
        //是否加班日
        if(extraWorkDay.contains(formatTime)){
            return true;
        }
        //是否节假日
        if(holiday.contains(formatTime)){
            return false;
        }
        //如果是1-5表示周一到周五  是工作日
        DayOfWeek week = dateTime.getDayOfWeek();
        if(week==DayOfWeek.SATURDAY||week==DayOfWeek.SUNDAY){
            return false;
        }
        return true;

    }

    public static void main(String[] args) {
        Boolean workingDay = isWorkingDay(System.currentTimeMillis());
        if(workingDay){
            System.out.println("工作日，加油，打工人");
        }else {
            System.out.println("开开心心过节，高高兴兴干饭！！！");
        }
    }
  
    /**
     *  初始化节假日
     */
    public static void initHoliday(){
        holiday.add("2021-01-01");
        holiday.add("2021-01-02");
        holiday.add("2021-01-03");
        holiday.add("2021-02-11");
        holiday.add("2021-02-12");
        holiday.add("2021-02-13");
        holiday.add("2021-02-14");
        holiday.add("2021-02-15");
        holiday.add("2021-02-16");
        holiday.add("2021-02-17");
        holiday.add("2021-04-03");
        holiday.add("2021-04-04");
        holiday.add("2021-04-05");
        holiday.add("2021-05-01");
        holiday.add("2021-05-02");
        holiday.add("2021-05-03");
        holiday.add("2021-05-04");
        holiday.add("2021-05-05");
        holiday.add("2021-06-12");
        holiday.add("2021-06-13");
        holiday.add("2021-06-14");
        holiday.add("2021-09-19");
        holiday.add("2021-09-20");
        holiday.add("2021-09-21");
        holiday.add("2021-10-01");
        holiday.add("2021-10-02");
        holiday.add("2021-10-03");
        holiday.add("2021-10-04");
        holiday.add("2021-10-05");
        holiday.add("2021-10-06");
        holiday.add("2021-10-07");
    }
    /**
     *  初始化额外加班日
     */
    public static void initExtraWorkDay(){
        extraWorkDay.add("2021-02-07");
        extraWorkDay.add("2021-02-20");
        extraWorkDay.add("2021-04-25");
        extraWorkDay.add("2021-05-08");
        extraWorkDay.add("2021-09-18");
        extraWorkDay.add("2021-09-26");
        extraWorkDay.add("2021-10-09");
    }
}

```

不得不说hutool工具包还是很强大的，还能根据时间获取农历，获取属相，星座等等
