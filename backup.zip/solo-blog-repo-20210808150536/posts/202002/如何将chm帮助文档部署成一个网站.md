title: 如何将chm帮助文档部署成一个网站？
date: '2020-02-19 21:12:30'
updated: '2020-02-22 21:49:58'
tags: [chm, Nginx]
permalink: /articles/2020/02/19/1582117950365.html
---
最近一直都是远程开发，然后刚好所用到的 Java 技术相对比较偏门，经常需要查阅 API 文档，很久之前在网上下载过一个 jdk1.8 的中文 chm 文档，查阅资料非常的方便实用，就想着能不能部署成一个网站。

## 什么是 chm 帮助文档？

> CHM 是英语“Compiled Help Manual”的简写，即“已编译的帮助文件”。CHM 是微软新一代的帮助文件格式，利用 HTML 作源文，把帮助内容以类似数据库的形式编译储存。

## 如何部署成网站

第一种：直接在浏览器当中输入：mk:@MSITStore:D:/jdk1.8.chm::/index.html
结果：最终会在 IE 浏览器当中打开。（使用 Google 浏览器和火狐浏览器都会跳转到 IE）

第二种：将 chm 转成 HTML 文件，然后在服务器上部署 HTML 文件就可以了。

### chm 文件转成 HTML 文件

在 windows 系统环境下，进入 cmd  通过命令

hh -decompile 输出文件夹 CHM 文件地址。

例如：
hh -decompile D:\HTML  D:\jdk1.8.chm     就将 chm 文件转换成 HTML 文件了。就是文件有点大

### HTML 文件部署到服务器上面

静态 HTML 部署的方式有很多，由于服务器上已经安装过 nginx，所以直接用过 nginx 部署。

1 将 api.hjljy.cn 域名映射到服务器的 IP 地址上面
2 将生成的 HTML 文件传到服务器的 nginx 指定的位置下面 :   /usr/local/nginx/api/api
3 配置 nginx 的代理处理

```
  server { 
	listen 80; 
	server_name api.hjljy.cn; 
	location / { 
		 root   /usr/local/nginx/api/api;
		index  index.html;
		} 
	}
```

4 重启 nginx  登陆 http://api.hjljy.cn/index.html 查看验证
