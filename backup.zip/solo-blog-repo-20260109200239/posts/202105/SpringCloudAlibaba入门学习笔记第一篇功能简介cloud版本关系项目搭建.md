title: Spring Cloud Alibaba 入门学习笔记第一篇：功能简介+cloud版本关系+项目搭建
date: '2021-05-28 15:16:45'
updated: '2021-06-10 14:43:46'
tags: [springcloud]
permalink: /articles/2021/05/28/1622186205108.html
---
![](https://b3logfile.com/bing/20201105.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

微服务大火的技术时代，怎么能不会点微服务技术呢！特此记录下Spring Cloud Alibaba的学习历程

# Spring Cloud Alibaba 入门学习笔记第一篇：功能简介+cloud版本关系

### SpringBoot ，SpringCloud， SpringCloud Alibaba相互间的关系

SpringBoot 官方网址：https://spring.io/projects/spring-boot
SpringCloud官方网址: https://spring.io/projects/spring-cloud
SpringCloud Alibaba官方网址: https://spring.io/projects/spring-cloud-alibaba ，[github](https://github.com/alibaba/spring-cloud-alibaba)

#### SpringBoot和SpringCloud的关系

SpringCloud用于处理多个服务之间的交互，例如：服务注册与发现，服务调用，接口路由，负载均衡等等
SpringBoot可以快速的开发部署一个服务，算是SpringCloud里面服务的一个默认实现。

#### SpringCloud和SpringCloud Alibaba的关系

SpringCloud框架对于服务间的交互行为，都有很多的框架进行实现，例如：服务注册与发现，就存在nacos, eureka, consul zookeeper等多个框架，同时也有一些框架慢慢的不在开源，维护，剔除：例如 eureka，spring-cloud-netflix删除了大量模块。
这样的话对于开发者来说就很难受，因此，就有了SpringCloud Alibaba的出现，

> Spring Cloud Alibaba为分布式应用程序开发提供了一站式解决方案。它包含开发分布式应用程序所需的所有组件，使您可以轻松地使用Spring Cloud开发应用程序。
> 使用Spring Cloud Alibaba，您只需添加一些注释和少量配置即可将Spring Cloud应用程序连接到Alibaba的分布式解决方案，并使用Alibaba中间件构建分布式应用程序系统。

### 相互间版本依赖

数据截止日期2021-5-28   信息来源AlibabaWiki：[版本说明](https://github.com/alibaba/spring-cloud-alibaba/wiki/%E7%89%88%E6%9C%AC%E8%AF%B4%E6%98%8E#%E7%BB%84%E4%BB%B6%E7%89%88%E6%9C%AC%E5%85%B3%E7%B3%BB)

|   | SpringBoot | SpringCloud | SpringCloudAlibaba |
| - | - | - | - |
| 最新 | 2.5.0 | 2020.0.2 | 2021.1 |
| 对应版本 | 2.4.x 以后 | 2020.0.x (推荐2020.0.2) | 2020.0以后的版本(推荐最新2021.1) |
| 对应版本 | 2.2.x, 2.3.x  推荐使用2.3.2.RELEASE | Hoxton（SR5后的只支持2.3.x）推荐使用 Hoxton.SR8 | 2.2.x.RELEASE 推荐使用2.2.5.RELEASE |

其他版本：Spring Cloud Dalston，Edgware，Finchley和Greenwich的生命周期均已终止，不再受支持。

### 主要功能和组件简介

功能：服务限流降级
相关组件：Sentinel：把流量作为切入点，从流量控制、熔断降级、系统负载保护等多个维度保护服务的稳定性。

功能：服务注册与发现，配置管理
相关组件：Nacos：一个更易于构建云原生应用的动态服务发现、配置管理和服务管理平台。

功能：分布式事务
相关组件：Seata：阿里巴巴开源产品，一个易于使用的高性能微服务分布式事务解决方案。

功能：队列消息
RocketMQ：一款开源的分布式消息系统，基于高可用分布式集群技术，提供低延时的、高可靠的消息发布与订阅服务。

功能：服务调用
Dubbo：Apache Dubbo™ 是一款高性能 Java RPC 框架。

# Spring Cloud Alibaba 搭建项目

### 1 创建项目，在pom文件当中添加如下代码

```
    <dependencyManagement>
        <dependencies>
            <dependency>
                <groupId>org.springframework.cloud</groupId>
                <artifactId>spring-cloud-dependencies</artifactId>
                <version>2020.0.2</version>
                <type>pom</type>
                <scope>import</scope>
            </dependency>
            <dependency>
                <groupId>com.alibaba.cloud</groupId>
                <artifactId>spring-cloud-alibaba-dependencies</artifactId>
                <version>2021.1</version>
                <type>pom</type>
                <scope>import</scope>
            </dependency>
        </dependencies>
    </dependencyManagement>
```

### 2 按需引入自己需要的组件

作为微服务，基本的服务注册与发现，服务的负载均衡远程调用是必须要有的，可以根据自己的需求选择相关的组件：
注册中心：nacos / consul / zookeeper / eureka
负载均衡远程调用: dubbo / loadbalancer +restTemplate / openFeign /robbion+restTemplate
其他的组件就可以根据自己的需求到时候再说了。
