title: JAVA面试题总结（不断添加整理当中。。。。。。）
date: '2019-03-08 15:33:01'
updated: '2019-03-08 15:33:01'
tags: [JAVA, 面试]
permalink: /articles/2019/03/06/1551855951942.html
---
![](https://img.hacpai.com/bing/20180128.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

最近要找工作了，复习总结一下面试题，总有些问题一直在问，总有些问题慢慢消失了，也总有些问题第一次遇到。
# JAVA 基础篇
*  [有了基本类型为什么还要包装类？](https://blog.csdn.net/min996358312/article/details/62894674)
           
*  ["=="和equals方法究竟有什么区别？](https://blog.csdn.net/topwilling/article/details/50975581)

*  [两个对象的hashCode()相等，则equals()也一定为true？](https://www.jianshu.com/p/17a02ad2f62b)

* [String，StringBuffer,StringBuilder的区别和联系](https://www.cnblogs.com/su-feng/p/6659064.html)

* [final, finally, finalize的区别](https://www.cnblogs.com/ktao/p/8586966.html)

* [Java抽象类与接口的区别](http://www.importnew.com/12399.html) 

# Java集合篇
* [List和Set，map的区别](https://www.cnblogs.com/IvesHe/p/6108933.html)
* [hashMap的实现原理](https://www.cnblogs.com/yangming1996/p/7997468.html)

* [List集合元素的正确删除方式](https://www.cnblogs.com/pcheng/p/5336903.html)

# JavaWeb篇
* [Session和Cookie区别](https://www.cnblogs.com/shiyangxt/articles/1305506.html) 

* [拦截器和过滤器的区别](https://blog.csdn.net/zxd1435513775/article/details/80556034)

* [Servlet的生命周期](https://www.cnblogs.com/lgk8023/p/6427977.html)

# Spring/SpringMVC/SpringBoot

* [为什么要使用spring](https://www.cnblogs.com/zmmi/p/7922186.html)

* [spring常用的三种注入方式](https://blog.csdn.net/a909301740/article/details/78379720)

* [spring使用了那些设计模式](https://www.cnblogs.com/hwaggLee/p/4510687.html)

* [springMVC执行流程](https://www.cnblogs.com/jiyukai/p/7629498.html)

* [springboot面试题](https://www.jianshu.com/p/63ad69c480fe/)
 
# 数据库篇
* [drop,delete与truncate的区别](https://www.cnblogs.com/zhizhao/p/7825469.html)

* [innodb和myisam的区别](https://www.cnblogs.com/y-rong/p/8110596.html)

# 面试总结
1. 技术栈不符合的公司需要好好考虑。例如：之前一直从事WEB开发，那么一些服务器方面的开发等等，就需要好好考虑了。
1. 面试是一个自我认识的过程，不要怕被面试官问到不会或者不理解的知识点。
1. 面试是需要良好的沟通，要对自己的项目，自己的技术，自己的编程思想做一个清楚的描述。