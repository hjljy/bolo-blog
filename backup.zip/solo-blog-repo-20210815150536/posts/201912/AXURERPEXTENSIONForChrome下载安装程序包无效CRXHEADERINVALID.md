title: AXURE RP EXTENSION For Chrome下载安装，程序包无效：“CRX_HEADER_INVALID”
date: '2019-12-05 15:14:33'
updated: '2019-12-05 15:14:33'
tags: [Chrome]
permalink: /articles/2019/12/05/1575530073762.html
---
Chrome 无法打开原型图
提示需要下载AXURE RP EXTENSION For Chrome 这个插件

百度网盘链接: https://pan.baidu.com/s/1Dvq0q1leKUpXwVQyyrAbtA 
提取码: 666z 

注意事项：
安装时提示 程序包无效：“CRX_HEADER_INVALID” 无法安装插件

这时可以将对应的crx文件后缀变成rar或者zip   解压出来，然后通过加载已经解压的扩展程序完成安装。