title: Redis学习日志之SpringBoot2.0+整合Redis（基于Redission）
date: '2019-03-14 11:23:20'
updated: '2019-03-14 11:23:20'
tags: [redis, springboot]
permalink: /articles/2019/03/14/1552533800142.html
---
![](https://img.hacpai.com/bing/20180623.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

> [海加尔金鹰  ———— 如野草般一岁一枯荣](https://www.hjljy.cn)

昨天完成了redis的简单安装[Redis学习日志之Linux下的安装](https://www.hjljy.cn/articles/2019/03/11/1552299085128.html)，今天就在项目当中简单整合使用一下
## 整合环境说明
JDK1.8版本 
idea开发工具
springboot2.1.0版本
## 为什么选择Redission?
springboot2.0之前的版本默认支持的是Jedis 但是在2.0后换成了Lettuce。
java连接redis最多的就是Jedis,Redisson,Lettuce这三种方式
简单说明介绍：[Redis的三个框架：Jedis,Redisson,Lettuce](https://www.cnblogs.com/liyan492/p/9858548.html)
最后选择了Redission，因为Redisson的宗旨是促进使用者对Redis的关注分离，从而让使用者能够将精力更集中地放在处理业务逻辑上。
## 在POM当中引入对应JAR
根据[Redission官方整合文档](https://github.com/redisson/redisson/tree/master/redisson-spring-boot-starter#spring-boot-starter)进行引入和使用：
```
        <!-- redisson -->
        <dependency>
            <groupId>org.redisson</groupId>
            <artifactId>redisson-spring-boot-starter</artifactId>
            <version>3.10.4</version>
        </dependency>
```
## 创建配置类RedissonConfig

```
package com.hjljy.blog.redission;

import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @Auther: 海加尔金鹰
 * @Date: 2019年03月12日  17:47
 * @Description:
 */
@Configuration
public class RedissonConfig {

    @Bean
    public RedissonClient getRedisson(){
        Config config = new Config();
        //单机模式  依次设置redis地址和密码
        config.useSingleServer().
                setAddress("redis://IP地址:6379"). 
                setPassword("你的密码");
        return Redisson.create(config);
    }
}
```
这里只配置了最基本的参数，redis的配置方式有多种，配置参数也有很多，具体见[官方参数配置说明（中文）](https://github.com/redisson/redisson/wiki/2.-%E9%85%8D%E7%BD%AE%E6%96%B9%E6%B3%95)

## 编写测试类进行测试
  在进行测试之前，由于使用的是阿里云服务器，所以需要在安全组当中开放6379端口，不然连接不上。

```
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class BlogApplicationTests {

    @Resource
    private RedissonClient redissonClient;

    @Test
    public void RedissionTest(){
        RBucket<String> key = redissonClient.getBucket("newday");
        key.set("新的数据");
        System.out.println("获取到新存入的数据："+key.get());
        // 获取字符串格式的数据
        RBucket<String> keyObj = redissonClient.getBucket("myname");
        String s = keyObj.get();
        System.out.println("获取到昨天存入的数据："+s);
    }
}
```
测试结果：

```
获取到新存入的数据：新的数据
[ ERROR] [2019-03-14 10:37:37] [redisson-netty-1-9] org.redisson.client.handler.CommandDecoder [204] - Unable to decode data. channel: [id: 0x704603a9, L:/192.168.0.147:10879 - R:47.94.139.213/47.94.139.213:6379], reply: ReplayingDecoderByteBuf(ridx=9, widx=9), command: (GET), params: [myname]
java.io.IOException: java.lang.NullPointerException
```
可以获取到项目当中新存入的数据，但是无法获取到昨天通过redis-cli存入的数据。
错误信息提示：无法解码数据，猜测可能是redis-cli存数据的编码和redission的编码不一致导致的。
最后网上找了很多的资料，找到了一个叫序列化策略的东西。大致的情况就是说redis-cli存数据时的序列化策略是string，但是redission的默认序列化策略是Jackson JSON 编码   [Redission官网配置参数序列化说明](https://github.com/redisson/redisson/wiki/2.-%E9%85%8D%E7%BD%AE%E6%96%B9%E6%B3%95)
## 修改配置类RedissionConfig如下

```
    @Bean
    public RedissonClient getRedisson(){
        Config config = new Config();
        //单机模式  依次设置redis地址和密码
        config.useSingleServer().
                setAddress("redis://IP地址:6379"). 
                setPassword("你的密码");
        config.setCodec(new StringCodec());
        return Redisson.create(config);
    }
```
最后结果如下：

```
  .   ____          _            __ _ _
 /\\ / ___'_ __ _ _(_)_ __  __ _ \ \ \ \
( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \
 \\/  ___)| |_)| | | | | || (_| |  ) ) ) )
  '  |____| .__|_| |_|_| |_\__, | / / / /
 =========|_|==============|___/=/_/_/_/
 :: Spring Boot ::        (v2.1.0.RELEASE)

获取到新存入的数据：新的数据
获取到昨天存入的数据：ycf
```
到这里简单的使用就完成了。
## 总结
1 RedissonClient 这个类很重要，可以看到数据的读取都是通过这个类进行的。
2 这么多种序列化方式，所以序列化可能是个坑，后面需要注意。
3 官方文档的说明很详细，没事可以多看看。
## 参考资料
[Redission官方文档](https://github.com/redisson/redisson/wiki/%E7%9B%AE%E5%BD%95)
[springboot 整合redisson](https://www.cnblogs.com/milicool/p/9201271.html)