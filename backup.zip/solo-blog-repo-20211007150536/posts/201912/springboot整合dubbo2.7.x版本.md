title: springboot整合dubbo2.7.x版本
date: '2019-12-06 14:55:33'
updated: '2019-12-06 14:55:33'
tags: [dubbo, dubbo-admin, springboot, zookeeper]
permalink: /articles/2019/12/06/1575615333350.html
---
![](https://img.hacpai.com/bing/20171216.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 什么是Dubbo?
> Apache Dubbo |ˈdʌbəʊ| 是一款高性能、轻量级的开源Java RPC框架，它提供了三大核心能力：面向接口的远程方法调用，智能容错和负载均衡，以及服务自动注册和发现。

是的，是 [Apache Dubbo](http://dubbo.apache.org/zh-cn/index.html)，不在是Alibaba Dubbo。原因简单来说就是Alibaba 将dubbo 移交给Apache开源社区进行维护。
详情见这两篇文章：
[Dubbo正式进入Apache开源孵化器](https://yq.aliyun.com/articles/633671?spm=a2c4e.11163080.searchblog.9.137b2ec19PhqJQ)
[从遇见到信任 | Apache Dubbo 的毕业之旅](https://yq.aliyun.com/articles/705347?spm=a2c4e.11163080.searchblog.26.50642ec1UylIRR)

### Dubbo2.7.x版本变化
1.  JDK版本需求上升到1.8
1.  包名更换：com.alibaba.dubbo - > org.apache.dubbo
1.  注册中心一分为三，变成注册中心，元数据中心，配置中心
1.  异步支持优化
1.  服务治理规则优化
......
### Dubbo生态系统
![图片.png](https://img.hacpai.com/file/2019/12/图片-baf46602.png)
此图来源于[Dubbo官网](http://dubbo.apache.org/zh-cn/ecology/index.html)

## SpringBoot 整合Dubbo2.7.x
环境信息：
JDK	1.8 
SpringBoot	 2.2.1
Dubbo 	2.7.4.1
准备工具：zookeeper  [官网下载地址](http://mirror.bit.edu.cn/apache/zookeeper/)，新版dubbo_admin [官网下载地址](https://github.com/apache/dubbo-admin)

### zookeeper 说明
> ZooKeeper 是一个开源的分布式协调服务，由雅虎创建，是 Google Chubby 的开源实现。
分布式应用程序可以基于 ZooKeeper 实现诸如数据发布/订阅、负载均衡、命名服务、分布式协
调/通知、集群管理、Master 选举、配置维护，名字服务、分布式同步、分布式锁和分布式队列
等功能。

Dubbo支持多种注册中心：redis,nacos,zookeeper.....  推荐使用zookeeper。
### zookeeper 安装启动

在官网下载好zookeeper之后，解压。
然后将conf文件夹下的zoo_sample.cfg文件复制一份重命名为zoo.cfg不做任何的修改。
进入bin文件夹下找到zkServer.cmd（windows环境下，linux使用zkServer.sh） 双击启动即可。
启动后默认端口为2181。 zookeeper在3.5.5版本后还会占用8080端口，需要注意。

### 新版Dubbo_Admin
使用前建议先阅读官方文档说明！！！！

可以通过官网readme说明进行操作,也可以直接使用IDEA拉取项目代码运行。
IDEA拉取项目之后先启动 DubboAdminApplication 这个类，默认8080端口，已被占用可以手动修改。
然后运行dubbo-admin-ui这个前端模块（找到package.json，然后找到npm run dev ，点击左侧绿色启动按钮即可）注意：需要安装node.js。默认8081端口，也是可以手动在index.js里面进行修改。
运行起来后访问 ：localhost:8081 就会出现如下画面，就表示启动成功了。
![图片.png](https://img.hacpai.com/file/2019/12/图片-9efde596.png)


### 创建springboot项目

先创建一个多模块的springboot项目，方便体验dubbo。

#### dubbo-api     	接口服务模块
pom文件内容：
```
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <parent>
        <groupId>com.hjljy</groupId>
        <artifactId>springboot_dubbo</artifactId>
        <version>0.0.1-SNAPSHOT</version>
        <relativePath/> <!-- lookup parent from repository -->
    </parent>
    <groupId>com.hjljy</groupId>
    <artifactId>dubbo_api</artifactId>
    <version>0.0.1-SNAPSHOT</version>
    <name>dubbo_api</name>
    <description>Demo project for Spring Boot</description>

    <properties>
        <java.version>1.8</java.version>
    </properties>

    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter</artifactId>
        </dependency>
..................

```

然后定义两个简单的接口
```
public interface TestService {
    String showName();
}
```
```
public interface TestService2 {
    String showName();
}
```
#### dubbo-provider  服务提供者
pom文件内容：
```
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter</artifactId>
        </dependency>
        <!--zookeeper 注册中心客户端引入 使用的是curator客户端 -->
        <dependency>
            <groupId>org.apache.dubbo</groupId>
            <artifactId>dubbo-dependencies-zookeeper</artifactId>
            <version>2.7.4.1</version>
            <type>pom</type>
            <exclusions>
                <exclusion>
                    <groupId>org.slf4j</groupId>
                    <artifactId>slf4j-log4j12</artifactId>
                </exclusion>
            </exclusions>
        </dependency>
        <!-- dubbo 2.7.x引入-->
        <dependency>
            <groupId>org.apache.dubbo</groupId>
            <artifactId>dubbo-spring-boot-starter</artifactId>
            <version>2.7.4.1</version>
        </dependency>
        <dependency>
            <groupId>com.hjljy</groupId>
            <artifactId>dubbo_api</artifactId>
            <version>0.0.1-SNAPSHOT</version>
        </dependency>
........ 

```
创建对应接口实现：
```
@Service(version = "1.0.0")
public class TestService2Impl implements TestService2 {
    @Override
    public String showName() {
        return "HELLO   TestService2";
    }
}
```
```
@Service(version = "1.0.0")
public class TestServiceImpl implements TestService {
    @Override
    public String showName() {
        return "HELLO   DUBBO";
    }
}
```
application配置文件配置：
```
# Spring boot application
spring.application.name=dubbo-provider-demo
# Base packages to scan Dubbo Component: @org.apache.dubbo.config.annotation.Service
dubbo.scan.base-packages=com.hjljy.dubbo_provider.impl   

# Dubbo Application
## The default value of dubbo.application.name is ${spring.application.name}
dubbo.application.name=${spring.application.name}

# Dubbo Protocol
dubbo.protocol.name=dubbo
dubbo.protocol.port=20880

## Dubbo Registry
dubbo.registry.address=zookeeper://127.0.0.1:2181

server.port=7010
```
注意事项：
* @Service一定要加上version 属性 并且是dubbo包下面的注解不是spring里面的注解
* base-packages 指定接口实现所在路径。
* dubbo的配置不再以spring开头。
#### dubbo-comsumer 服务消费者

pom文件内容：
```
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter</artifactId>
        </dependency>
        <!--zookeeper 注册中心客户端引入 使用的是curator客户端 -->
        <dependency>
            <groupId>org.apache.dubbo</groupId>
            <artifactId>dubbo-dependencies-zookeeper</artifactId>
            <version>2.7.4.1</version>
            <type>pom</type>
            <exclusions>
                <exclusion>
                    <groupId>org.slf4j</groupId>
                    <artifactId>slf4j-log4j12</artifactId>
                </exclusion>
            </exclusions>
        </dependency>
        <!-- dubbo 2.7.x引入-->
        <dependency>
            <groupId>org.apache.dubbo</groupId>
            <artifactId>dubbo-spring-boot-starter</artifactId>
            <version>2.7.4.1</version>
        </dependency>
        <dependency>
            <groupId>com.hjljy</groupId>
            <artifactId>dubbo_api</artifactId>
            <version>0.0.1-SNAPSHOT</version>
        </dependency>
```
消费创建的服务
``` java
@RestController
public class TestDubboController {
    @Reference(version = "1.0.0")
    TestService2 service2;
    @Reference(version = "1.0.0")
    TestService service;

    @GetMapping("test1")
    public String test1(){
        return  service.showName();
    }
    @GetMapping("test2")
    public String test2(){
        return  service2.showName();
    }
}
```
application配置文件配置：
```
spring.application.name=dubbo-consumer-demo
dubbo.registry.address=zookeeper://127.0.0.1:2181
server.port=7000
```
#### 启动程序验证DUBBO
先启动	DubboProviderApplication   
然后启动	DubboConsumerApplication
最后访问   http://127.0.0.1:7000/test1   http://127.0.0.1:7000/test2
![图片.png](https://img.hacpai.com/file/2019/12/图片-963ed0c4.png)
成功返回信息，验证成功。

然后登陆dubbo_admin查看提供的服务：
![图片.png](https://img.hacpai.com/file/2019/12/图片-74c2c6eb.png)

到这里完成的springboot整合dubbo2.7.x就完成了。

---
完整代码地址：https://gitee.com/hjljy/springboot_dubbo