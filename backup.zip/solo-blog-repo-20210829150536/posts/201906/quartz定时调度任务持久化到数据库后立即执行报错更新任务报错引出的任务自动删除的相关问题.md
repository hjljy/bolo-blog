title: quartz定时调度任务持久化到数据库后立即执行报错，更新任务报错引出的任务自动删除的相关问题
date: '2019-06-27 18:22:17'
updated: '2019-06-27 18:22:17'
tags: [quartz]
permalink: /articles/2019/06/27/1561630937006.html
---
![](https://img.hacpai.com/bing/20180524.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

最近修改项目BUG，定时任务这一块有很多的BUG，改了很久，记录一下相关BUG
## 问题1
问题场景：
 1.  新建一个定时任务，设置定时任务执行时间：2019-06-26 18:00:00  （即只在这个时间点执行一次，然后就再也不执行了）
 2. 在到达执行时间之前，进行更新和立即执行都不存在任何问题。
 3. 在到达执行时间之后，进行更新和立即执行都报错
 
错误信息：<font color="red">
org.quartz.JobPersistenceException: Couldn’t store trigger: The job (DEFAULT.task-etl-19) referenced by the trigger does not exist. </font>

问题具体原因查找过程：


 1. 创建一个周期任务，设置任务每分钟执行一次。发现不会出现这种情况。
 2. 查看任务持久化物理表，发现定时任务（只执行一次的定时任务），在执行后会自动删除。
 3. 进行代码断点，查看在何处进行的删除，没找到。
 4. 进行各种任务属性对比初步推断是quartz框架自身的一种设计，如果没有下次执行时间的任务，会自动进行删除。

在网上查找很久，找到了一篇文章，[Quartz Scheduler 更新任务触发器](https://www.cnblogs.com/daxin/archive/2013/05/30/3109296.html)  里面提到：

> null if a Trigger with the given name & group was not found and removed from the store (and the new trigger is therefore not stored), otherwise the first fire time of the newly scheduled trigger is returned.
>-
> 替换失败的原因一般有两种：一种情况是传入的triggerKey没有与之匹配的，另外一种情况就是旧触发器的触发时间已经全部完成，在触发完成后调度引擎会自动清除无用的触发器，这种情况也会匹配不到。

证明了我的判断，但是我在公司不知道怎么回事打不开quartz的官网：http://www.quartz-scheduler.org/

最后问题的解决办法：
既然已经删除了，那么就判断一下是否存在这个定时任务，不存在就重新创建一下。

## 问题2
问题场景：
这个问题是在解决问题1的时候出来的，如何判断定时任务是否存在？
最开始的想法是直接查询对应的定时任务表（是qrtz开头的表，不是自定义的任务表），判断是否存在。

最后解决办法：查看API，在Scheduler接口当中，已经有对应的方法进行判断了。当然还有很多其他的方法。不得不说这个框架很强大啊。

```

    boolean checkExists(JobKey var1) throws SchedulerException;

    boolean checkExists(TriggerKey var1) throws SchedulerException;
```
## 问题3
问题场景：在处理完问题2后，重新创建任务的时候报错

错误信息：<font color="red">
org.quartz.JobPersistenceException: Based on configured schedule, the given trigger 'xxxxxx' will never fire.. </font>

问题原因：无法创建一个永不触发的定时任务

问题解决办法：点击立即执行时，更具任务信息重新创建任务，但是设置一个比较大的定时任务执行时间。例如设置执行时间为：2055-01-01 02:00:00  然后就可以立即执行了。更新时直接提示时间过期，需要重新设置。