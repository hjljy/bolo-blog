title: Nginx学习日志（六）Linux下设置开机自启动
date: '2020-09-15 15:54:41'
updated: '2020-09-15 15:54:56'
tags: [Nginx, linux]
permalink: /articles/2020/09/15/1600156481493.html
---
![](https://b3logfile.com/bing/20181009.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

最近升级了下linux服务器配置，重启之后，发现要敲一堆命令行，挺麻烦的，能开启自启动就好了

参考资料：[在Linux中利用Service命令添加系统服务及开机自启动](https://blog.csdn.net/u013554213/article/details/78792686)
[Linux下设置nginx开机自动启动](https://www.jianshu.com/p/101122ef907b)

## 1 编写服务启动脚本

编写一个脚本，然后把它放在/etc/init.d这个目录下，再用service + 脚本名字 运行即可
linux 下可以通过vim创建脚本然后添加脚本内容，我个人比较喜欢直接在windows上创建好，然后用winscp上传到服务器上面（需要注意windows和linux特殊字符的问题）

```
vim /etc/init.d/nginx
```

脚本内容如下：[官方文档](https://www.nginx.com/resources/wiki/start/topics/examples/redhatnginxinit/)

```
#!/bin/sh
#
# nginx - this script starts and stops the nginx daemon
#
# chkconfig:   - 85 15
# description:  NGINX is an HTTP(S) server, HTTP(S) reverse \
#               proxy and IMAP/POP3 proxy server
# processname: nginx
# config:      /etc/nginx/nginx.conf
# config:      /etc/sysconfig/nginx


# Source function library.
. /etc/rc.d/init.d/functions

# Source networking configuration.
. /etc/sysconfig/network

# Check that networking is up.
[ "$NETWORKING" = "no" ] && exit 0

pidfile="/usr/local/nginx/logs/nginx.pid"
nginx="/usr/local/nginx/sbin/nginx"
prog=$(basename $nginx)

NGINX_CONF_FILE="/usr/local/nginx/conf/nginx.conf"

[ -f /etc/sysconfig/nginx ] && . /etc/sysconfig/nginx

lockfile=/var/lock/subsys/nginx

make_dirs() {
   # make required directories
   user=`$nginx -V 2>&1 | grep "configure arguments:.*--user=" | sed 's/[^*]*--user=\([^ ]*\).*/\1/g' -`
   if [ -n "$user" ]; then
      if [ -z "`grep $user /etc/passwd`" ]; then
         useradd -M -s /bin/nologin $user
      fi
      options=`$nginx -V 2>&1 | grep 'configure arguments:'`
      for opt in $options; do
          if [ `echo $opt | grep '.*-temp-path'` ]; then
              value=`echo $opt | cut -d "=" -f 2`
              if [ ! -d "$value" ]; then
                  # echo "creating" $value
                  mkdir -p $value && chown -R $user $value
              fi
          fi
       done
    fi
}

start() {
    [ -x $nginx ] || exit 5
    [ -f $NGINX_CONF_FILE ] || exit 6
    make_dirs
    echo -n $"Starting $prog: "
    daemon $nginx -c $NGINX_CONF_FILE
    retval=$?
    echo
    [ $retval -eq 0 ] && touch $lockfile
    return $retval
}

stop() {
    echo -n $"Stopping $prog: "
    killproc $prog -QUIT
    retval=$?
    echo
    [ $retval -eq 0 ] && rm -f $lockfile
    return $retval
}

restart() {
    configtest || return $?
    stop
    sleep 1
    start
}

reload() {
    configtest || return $?
    echo -n $"Reloading $prog: "
    killproc $prog -HUP
    retval=$?
    echo
}

force_reload() {
    restart
}

configtest() {
  $nginx -t -c $NGINX_CONF_FILE
}

rh_status() {
    status $prog
}

rh_status_q() {
    rh_status >/dev/null 2>&1
}

case "$1" in
    start)
        rh_status_q && exit 0
        $1
        ;;
    stop)
        rh_status_q || exit 0
        $1
        ;;
    restart|configtest)
        $1
        ;;
    reload)
        rh_status_q || exit 7
        $1
        ;;
    force-reload)
        force_reload
        ;;
    status)
        rh_status
        ;;
    condrestart|try-restart)
        rh_status_q || exit 0
            ;;
    *)
        echo $"Usage: $0 {start|stop|status|restart|condrestart|try-restart|reload|force-reload|configtest}"
        exit 2
esac
```

## 2 主要配置修改

```
pidfile="/usr/local/nginx/logs/nginx.pid"   //nginx.pid所在位置
nginx="/usr/local/nginx/sbin/nginx"       //nginx 执行程序所在位置
prog=$(basename $nginx)

NGINX_CONF_FILE="/usr/local/nginx/conf/nginx.conf" //nginx 配置文件所在位置
```

如果找不到，或者忘记了上述文件所在位置，可以通过命令find 查找

```
find / -name nginx
```

## 3 权限授予

```
chmod a+x /etc/init.d/nginx //a表示所有，+表示添加，x表示可执行
```

## 4 service启动并设置自启动

```
service nginx start 启动
service nginx restart  重启
service nginx stop 停止
```

如果执行没有问题就可以通过chkconfig 命令设置开机启动

```
chkconfig --add nginx   //先执行
chkconfig nginx on     //后执行
```

最后可以通过chkconfig --list 查看自启动程序

## 5 问题总结

1 启动Nginx时一直卡着不动在 Starting nginx (via systemctl):  但是实际上还是启动成功了。
查看文件提示：PID file /usr/local/nginx/logs/nginx.pid not readable (yet?) after start.
大概率是因为  pidfile="/usr/local/nginx/logs/nginx.pid" 这个文件位置和nginx.conf 里面的pid文件位置不对导致的。

另一种处理方法：（未验证）
在/usr/lib/systemd/system/nginx.service中添加入下内容
ExecStartPost=/bin/sleep 0.1

2  启动nginx失败 提示 not bind()
简单的端口占用问题，找到端口，关闭就好了。

## 6 扩展（docker自启动）

见资料：[docker 设置容器开启自启动(无须写脚本)](https://blog.csdn.net/weixin_40461281/article/details/92630709)
