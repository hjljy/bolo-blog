title: Nginx学习日志（二）通过反向代理将不同域名映射到不同的端口
date: '2020-02-01 23:37:24'
updated: '2020-02-01 23:51:00'
tags: [Nginx]
permalink: /articles/2020/02/01/1580571444782.html
---
# 本文场景

由于自己进行学习，所以只买了一台服务器，但是想弄多个项目部署在同一台机器上，通过不同的域名访问不同的项目。例如：
输入  www.xxx.com  访问的是服务器上 8080 端口的项目
输入  www.yyy.com  访问的是服务器上 8081 端口的项目
最后决定通过 Nginx 反向带来实现。

# 什么是 Nginx 反向代理？

反向代理（Reverse Proxy）： 是指以代理服务器来接受 internet 上的连接请求，然后将请求转发给内部网络上的服务器，并将从服务器上得到的结果返回给 internet 上请求连接的客户端

# Nginx 反向代理简单实现

准备一台服务器（该服务器的 IP 需要已经和域名进行解析，一个 IP 可以解析多个域名）：

- 一个安装好的 Nginx
- tomcat1 ：127.0.0.1：8080
- tomcat2 ：127.0.0.1：8081

安装完毕 Nginx 后，进入 conf 下面找到 nginx.conf 文件。
找到 http 下面的 server，进行如下配置一个 server 表示一个代理

```
server { 
	listen 80;
	server_name 域名A; 
	location / {
		proxy_pass http://localhost:8080; 
		proxy_set_header Host $host; 
		proxy_set_header X-Real-IP $remote_addr; 
		proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for; 
		} 
}
server { 
	listen 80; 
	server_name 域名B; 
	location / { 
		proxy_pass http://localhost:8081; 
		proxy_set_header Host $host; 
		proxy_set_header X-Real-IP $remote_addr; 
		proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for; 
		} 
} 
```

然后进入 nginx/sbin 下面 重启 nginx

重启之后，就可以通过域名 A 访问到服务器 8080 端口的项目了。
