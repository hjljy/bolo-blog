title: Vue3.0开发之整合vue-admin-template模板
date: '2021-06-23 11:14:45'
updated: '2021-06-23 12:06:54'
tags: [vue]
permalink: /articles/2021/06/23/1624418085143.html
---
![](https://b3logfile.com/bing/20181021.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 起源

vue-admin-template模板算是一个比较好的前端开发模板，不过作者好像没有出vue3.0版本的，所以刚好自己在学习vue3.0，就想到开发一个vue3.0的模板，当然大部分代码都是参照vue-admin-template模板的。

目前已经完成了大部分的整合开发：[vue3.0-admin-template](https://github.com/hjljy/vue-admin-template)

## 过程

过程无非就是copy代码，修改报错，运行起来，查看效果！！！

整个过程的难点主要是在于修改报错，vue3.0的变化，element plus的变化都是需要去了解的，然后还没有多少的资料可供参考。

## 总结

主要记录下整合当中感受到的变化，遇到的问题，处理的方式

1. export ‘default‘ (imported as ‘Vue‘) was not found in ‘vue   无法直接import vue, 要通过createapp创建
2. vue router的addRouters方法不存在了
3. [vue3 ‘.native‘ modifier on ‘v-on‘ directive is deprecated.](https://blog.csdn.net/qq_33891000/article/details/111678309 "点击查看处理方式")
4. 'v-slot' directive must be owned by a custom element   处理方式：使用v-slot的元素外层包裹一个div即可
5. "Maximum recursive updates exceeded" when updating an array with elements from a v-for function ref    处理方式：如果一个变量在for循环里面被赋值了，出了for循环之后再次被赋值就会报这个告警（不是错误），我感觉这个是框架的bug！！！
6. [Catch all routes (&#34;*&#34;) must now be defined using a param with a custom regexp](https://blog.csdn.net/Dawnchen1/article/details/116742166)
7. [＜router-view＞ can no longer be used directly inside ＜transition＞](https://blog.csdn.net/ncj393437906/article/details/115120674)
8. element plus也存在大部分样式或者使用上的变更，需要根据element plus的文档进行对比
