title: springboot整合MongoDB
date: '2019-12-18 23:24:59'
updated: '2019-12-18 23:24:59'
tags: [mongodb, springboot]
permalink: /articles/2019/12/18/1576682699394.html
---
![](https://img.hacpai.com/bing/20190925.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 什么是MongoDB?

>  MongoDB是为现代应用程序开发人员和云时代构建的基于文档的通用分布式数据库

### MongoDB Windows下的安装

网上安装教程一大堆，不过官方网站的教程最详细：[官网windows下安装MongoDB](https://docs.mongodb.com/manual/tutorial/install-mongodb-on-windows/)

安装完毕之后如果不出错的话，就可以在计算机的服务里面找到一个：MongoDB Server 的服务。

### MongoDB 数据库

成功安装之后，可以通过安装目录bin下的mongo.exe 连接上MongoDB 数据库。输入help 可以查看相关帮助信息。
![image.png](https://img.hacpai.com/file/2019/12/image-dcd6993f.png)

常用操作：
show dbs        查看全部数据库

use  dbname   切换到指定名称数据库，如果没有就创建

show collections   获取指定数据库下的所有集合

db.createCollection("user")   在当前数据库下创建一个名为 user的集合

db.user.insert({"name":"hjljy","age":18})  向user集合里面插入一条数据

db.user.find()   查看user集合全部数据

其他操作见help或者官方网站说明：https://docs.mongodb.com/manual/tutorial/insert-documents/

![image.png](https://img.hacpai.com/file/2019/12/image-cd3536ed.png)

## springboot整合MongoDB

### 第一步 引入JAR
```
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-data-mongodb</artifactId>
        </dependency>
```

### 第二步 设置mongodb配置


``` javal
	#按照官网安装的mongodb是默认没有开启用户认证的，是不需要任何账号密码的
	spring.data.mongodb.url= mongodb://127.0.0.1:27017/test 
	# 开启用户认证之后设置用户密码
	#spring.data.mongodb.url=mongodb://username:password@127.0.0.1:27017/test 
```
### 第三步 编写测试类，查看效果

编写一个简单user类
```
public class User {
    private String name;
    private String address;
	// 省略 getter setter ....
}
```
直接在测试类中写测试
```
@SpringBootTest
class MongodbApplicationTests {

    @Autowired
    MongoTemplate mongoTemplate;
    @Test
    void contextLoads() {
        User user = new User();
        user.setName("hjljy");
        user.setAddress("chengdu");

        User user2 = new User();
        user2.setName("xxx");
        user2.setAddress("chengdu");
        //向t1集合里面插入一条数据
        mongoTemplate.insert(user,"t2");

        mongoTemplate.insert(user2,"t2");

        List<User> all = mongoTemplate.findAll(User.class, "t2");

        all.stream().forEach(use -> {
            System.out.println(use.toString());
        });
    }
}

```
结果如下：
```
name:hjljy,address:chengdu
name:xxx,address:chengdu
```

### 简单总结
MongoTemplate 这个类基本包含了所有和mongodb相关的操作，只需要在使用时继承这个类就可以了。
如果想直接存一个string字符串到mongodb里面的话，必须时json字符串格式。