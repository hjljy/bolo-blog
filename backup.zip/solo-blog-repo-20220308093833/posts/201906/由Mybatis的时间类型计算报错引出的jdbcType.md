title: 由Mybatis的时间类型计算报错引出的jdbcType
date: '2019-06-04 11:33:36'
updated: '2019-06-04 11:33:36'
tags: [mybatis]
permalink: /articles/2019/06/04/1559619216198.html
---
![](https://img.hacpai.com/bing/20180106.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 问题说明

最近在工作中有一个业务需求：传入一个时间，和数据库某个时间字段进行运算，返回相差的天数。很简单的一个需求，之前sql方面比较菜，都是现将数据查询出来然后在进行计算，刚好最近写了很多的sql,有所成长，知道可以通过ceil函数直接一条sql就能查询出我想要的数据，不需要查询出来之后在进行运算。

> [oracle 两个时间相减](https://www.cnblogs.com/zhaojinhui/p/3999469.html)

## 出现的错误

sql和代码都写好之后，测试报错: ==ORA-00932: 数据类型不一致==
然后检查数据库字段类型，检查参数类型，都是Date类型。这个时候有点蒙圈

## 问题原因
最后一想，既然类型一致，那么在传参的时候传的是什么类型呢？查看mybatis sql日志。sql日志第二行，参数后面的类型显示为：timestamp。就想到了在传参的时候就指定参数类型，也就是jdbcType。设置了jdbcType=DATE之后问题就解决了。

>  下面是在网上找的jdbcType关系说明
> ```
> JDBC Type           Java Type  
> CHAR                String  
> VARCHAR             String  
> LONGVARCHAR         String  
>NUMERIC             java.math.BigDecimal  
>DECIMAL             java.math.BigDecimal  
>BIT                 boolean  
>BOOLEAN             boolean  
>TINYINT             byte  
>SMALLINT            short  
>INTEGER             int  
>BIGINT              long  
>REAL                float  
>FLOAT               double  
>DOUBLE              double  
>BINARY              byte[]  
>VARBINARY           byte[]  
>LONGVARBINARY       byte[]  
>DATE                java.sql.Date  
>TIME                java.sql.Time  
>TIMESTAMP           java.sql.Timestamp  
>CLOB                Clob  
>BLOB                Blob  
>ARRAY               Array  
>DISTINCT            mapping of underlying type  
>STRUCT              Struct  
>REF                 Ref  
>DATALINK            java.net.URL[color=red][/color]  
> ```

## jdbcType的作用
问题解决之后，想着之前基本上没怎么设置过jdbcType,然后抱着学习的想法，在网上查找资料，了解一下具体作用。
> [MyBatis JdbcType 介绍 ](https://hacpai.com/article/1541648456378)
> [记自己在mybatis中设置jdbcType的一个坑](https://www.cnblogs.com/DDgougou/p/8578618.html)
> [Mybatis中的jdbcType的作用](https://my.oschina.net/architectliuyuanyuan/blog/1806447)

简单来说就是：当执行mapper文件的时候，参数映射为空，那么无法确定他的具体类型，这个时候就需要jdbcType来确定类型。 

# 一个额外的发现
使用Navicat Premiun12运行sql的时候，如果A字段类型是varchar。下面的sql在Navicat Premiun12是可以成功运行的：
==select * from Table  where A =1==
但是该语句如果放在mapper当中的话必须加上引号：
==select * from Table  where A ='1'==