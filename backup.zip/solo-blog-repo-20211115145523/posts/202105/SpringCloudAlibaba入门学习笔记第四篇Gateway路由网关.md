title: Spring Cloud Alibaba 入门学习笔记第四篇：Gateway路由网关
date: '2021-05-31 11:24:57'
updated: '2021-06-10 14:42:31'
tags: [springcloud, gateway]
permalink: /articles/2021/05/31/1622431497283.html
---
![](https://b3logfile.com/bing/20191026.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 什么是Gateway路由网关

关于Gateway路由网关，这篇文章介绍的非常详细：[Gateway网关简介及使用](https://blog.csdn.net/rain_web/article/details/102469745)

Spring Cloud Gateway 特性：（官方文档机翻）

```
	基于 Spring Framework 5、Project Reactor 和 Spring Boot 2.0

	能够匹配任何请求属性的路由。

	谓词和过滤器特定于路由。

	断路器集成。

	Spring Cloud DiscoveryClient 集成

	易于编写谓词和过滤器

	请求速率限制

	路径重写
```

Spring Cloud Gateway： [官方文档地址](https://spring.io/projects/spring-cloud-gateway)

总的来说就是一个牛皮的基于Spring WebFlux的请求处理框架

## 简单使用

### 引入JAR

```xml
    <dependency>
        <groupId>org.springframework.cloud</groupId>
        <artifactId>spring-cloud-starter-gateway</artifactId>
    </dependency>
    <!--        nacos 注册中心-->
    <dependency>
        <groupId>com.alibaba.cloud</groupId>
        <artifactId>spring-cloud-starter-alibaba-nacos-discovery</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.cloud</groupId>
        <artifactId>spring-cloud-starter-loadbalancer</artifactId>
    </dependency>
```

### 配置路由

```yml
server:
  port: 8000
spring:
  cloud:
    gateway:
      discovery:
        locator:
          enabled: true  # 开启路由网关服务发现
          lower-case-service-id: true  # 服务名转为小写
          url-expression: 'lb://'+serviceId   # 服务调用方式  serviceId表示注册中心的服务名称
      routes:
        # 服务转发
        - id: test-service  #必填 路由id
          uri: lb://service-a   # 必填 对应上面的url-expression   表示调用注册中心里面的名为service-a的服务
          predicates:      # 必填 至少有一种匹配方式
            - Path=/api/**  # 匹配所有api开头的路径    （其他匹配方式见官方文档）
          filters:     # 非必填
            - StripPrefix=1  # 将路径的第一个值去掉后转发 例如 /api/getUser  会变成 /getUser
        # 路由转发
        - id: cookie_route
          uri: http://hjljy.cn/    # 转发到http://hjljy.cn/
          predicates:
            - Cookie=name, hjljy # 如果携带cookie,参数名为name,值为hjljy,则转发
    nacos:
      server-addr: 127.0.0.1:8848  # 注册中心地址
      discovery:
        service: gateway
```

### 使用测试

1 启动nacos注册中心
2 启动路由网关服务（需要先保证注册中心存在一个名为service-a的服务，并且有个接口 /getUser ）
3 访问 127.0.0.1:8000/api/getUser   查看是否返回正确的数据

### 注意事项

- 需要去掉对spring-boot-starter-web 的依赖，不能同时存在
- 服务名避免使用下划线链接
