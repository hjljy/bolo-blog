title: 记录——IDEA如何打普通JAR包
date: '2019-10-15 16:17:25'
updated: '2021-11-06 16:55:42'
tags: [IDEA, JAR]
permalink: /articles/2019/10/15/1571127445525.html
---
![](https://img.hacpai.com/bing/20181122.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 正文

习惯了用maven命令打包，有点忘记了如何打一个普通的jar包了，特此记录一下。
jar包分两种：一种是有main函数的可以直接执行的jar包，一种是没有main函数，不可以直接执行的jar包（通常是工具包）

# 普通JAR包（不可以直接执行的jar）

1 点击project structure 找到Artifacts  点击加号，选择jar --Empty
![图片.png](https://img.hacpai.com/file/2019/10/图片-10646566.png)

2 修改jar名字,并把右边的compile output拉到左边的jar里面  然后确定保存
![图片.png](https://img.hacpai.com/file/2019/10/图片-c4163b8e.png)

3  点击build  选择build artifacts   进行build就可以了。
![图片.png](https://img.hacpai.com/file/2019/10/图片-62176d38.png)

4 对应的jar就打包完成了。
![图片.png](https://img.hacpai.com/file/2019/10/图片-cfa413d6.png)

# 可直接执行JAR包（有main函数）

重复上面1 2步操作
3 然后点击create Mainfest 选择项目目录，直接确定即可
![图片.png](https://img.hacpai.com/file/2019/10/图片-8ef1e15a.png)

4 点击jar名称，然后设置对应的main函数位置。设置完毕点击确定即可
![图片.png](https://img.hacpai.com/file/2019/10/图片-53ab7f7f.png)

5 点击build，选择对应的artifacts  进行build就可以了。

6 测试是否成功，不报错，正确执行main里面的代码就成功了。
![图片.png](https://img.hacpai.com/file/2019/10/图片-73f2c137.png)
