title: SpringBoot+Mybatis-plus：使用枚举接收参数并返回数据
date: '2021-04-16 15:06:57'
updated: '2021-09-22 15:40:27'
tags: [springboot, mybatis-plus]
permalink: /articles/2021/04/16/1618556817398.html
---
# SpringBoot+Mybatis-plus：使用枚举接收参数并返回数据

最近项目当中大量使用到枚举，特此记录下项目当中使用枚举的好处，场景，使用方式。

## 枚举的好处

1. 可读性高， 易理解
2. 统一参数类型，避免传参错误
3. 线程安全，全局唯一，无法修改

## 枚举使用场景

在实际的使用当中，当某个对象或者某个属性，需要有多个可供选择的状态或者描述，例如人的性别，支付的状态，错误的类型等等，都可以使用枚举。

## 枚举在项目中的使用

通常在项目当中会存在两种形式的枚举

### 第一种形式

```Java
/**
 * 性别枚举
 *
 * @author hjljy
 */
@Getter
public enum SexEnum {
    /**
     * 性别枚举
     */
    DEFAULT(-1, "保密"),
    WOMAN(0, "女"),
    MAN(1, "男");

    @EnumValue //标记存储到数据库的值
    @JsonValue //标记json返回的值
    private final Integer code;

    private final String remark;

    SexEnum(Integer code, String remark) {
        this.code = code;
        this.remark = remark;
    }

}
```

### 第二种形式

```java
/**
 * 用户类型枚举
 *
 * @author hjljy
 */
public enum SysUserTypeEnum {
    /**
     * 超级管理员
     */
    SUPER_ADMIN,
    /**
     * 系统管理员
     */
    SYS_ADMIN,
    /**
     * 普通管理员
     */
    ADMIN,
    /**
     * 普通账号
     */
    NORMAL
}
```

第一种形式，通常是使用的自定义的属性（code,remark）来进行判断和保存到数据库的
第二种形式，是直接使用的SUPER_ADMIN 这个实例来判断和保存的。

### 实体类的枚举字段保存到数据库，并且返回时自动映射到枚举属性上

如果是第一种形式的枚举，Mybatis-plus提供了相关的处理方式，可以进行枚举保存和隐射处理。官方文档地址：[mybatis-plus枚举处理](https://mp.baomidou.com/guide/enum.html)
具体处理方式：
第一步，用@EnumValue 	标记响应要保存在数据库的值。
第二步，springboot配置文件当中添加配置

```java
mybatis-plus:
    # 支持统配符 * 或者 ; 分割   切换成自己枚举所在的包
    typeEnumsPackage: com.baomidou.springboot.entity.enums
```

如果是第二种形式的枚举，没有任何自定义的字段，无需任何操作，直接正常保存和返回就可以，保存到数据库的内容就是枚举类型的名称，例如：SUPER_ADMIN ，SYS_ADMIN。

### 实体类枚举字段返回给前端

第一种形式的枚举，在需要返回的字段上添加@JsonValue //标记为json返回的值  注意:只能返回一个字段，不能返回多个。
第二种形式，无需处理。

### 实体类枚举字段接收前端参数

第一种形式的枚举，在添加了@JsonValue注解的情况下，直接接受对应字段的值即可正确的封装。例如：当前端传入的值是'1','0','-1'就会自动映射。
第二种形式，无需处理。

### 注意事项说明

1 枚举的比较，第二种形式的枚举在和字符串进行比较时，需要用到name()方法，例如：

```java
SysUserTypeEnum.SUPER_ADMIN.name().equels("SUPER_ADMIN")
```

2 无法接收前端的数字类型，或者无法接收的数字类型最后映射的结果错乱，报错等情况，让前端将数字类型转成string类型传给后端即可。原因是因为，枚举类型映射如果是数字类型会去根据角标进行匹配，角标是从0开始的，所以尽管你使用@JsonValue标记的是Intger code，但是还是会根据角标去匹配，所以需要转成string。

### 存储到数据库的类型

目前项目当中基本上是存的int类型，即枚举当中的code值，但是发现非常的不友好，每次看数据库的时候都不知道代表什么，建议经量避免存int，可以考虑使用string类型。虽然int占用空间小，但是这点空间意义不大，而且枚举类字段添加索引的意义不大
