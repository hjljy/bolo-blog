title: mybatis-plus max函数，sum函数的使用
date: '2021-02-19 18:32:45'
updated: '2021-09-22 15:41:28'
tags: [mybatis-plus]
permalink: /articles/2021/02/19/1613730765652.html
---
![](https://b3logfile.com/bing/20200628.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

最近在使用mybatis-plus,发现在对于一些简单函数的使用，官方文档上面没有说明，特此记录下自己的使用方式

## max,min,sum函数的使用

```
 QueryWrapper<MemberLevel> queryWrapper = new QueryWrapper<>();
 queryWrapper.select("max(level_sort) as levelSort");
```

相当于sql : select max(level_sort) as levelSort from member_level

其中的max可以换成min,sum等函数 就是如此的简单
