title: 本地启动dubbo服务端和消费端，调用不到的问题
date: '2019-06-13 15:53:32'
updated: '2019-06-13 15:53:32'
tags: [tomcat]
permalink: /articles/2019/06/13/1560412412744.html
---
在本地通过IDEA，用同一个tomcat分别在8088和8089端口启动了dubbo服务端和消费端，结果发现在接口调用的时候，调用不到，并且在项目启动时还报错：dubbo Can not lock the registry cache file以及其他的各种错误。

最后解决方式：在项目启动路径上加上项目路劲，
原来两个项目的启动路径分别是:localhost:8088        localhost：8089
修改后变成：:localhost:8088 /xx     localhost:8089/yy 就可以没有任何的问题了。

问题原因：猜测可能是由于使用的同一个tomcat启动两个项目，然后项目路劲相同的原因。