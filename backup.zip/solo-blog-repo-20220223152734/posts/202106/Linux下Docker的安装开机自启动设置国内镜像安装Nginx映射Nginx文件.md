title: Linux下Docker的安装，开机自启动，设置国内镜像，安装Nginx，映射Nginx文件
date: '2021-06-08 15:11:23'
updated: '2021-10-26 10:11:59'
tags: [linux, docker, Nginx]
permalink: /articles/2021/06/08/1623136283806.html
---
![](https://b3logfile.com/bing/20180529.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 安装Docker

官方有Linux下各个发行版（centos,Ubuntu等等）的安装文档：https://docs.docker.com/engine/install/centos/

## Docker开机自启动

> systemctl enable docker

## Docker设置国内镜像地址

来源：https://www.daocloud.io/mirror

> curl -sSL https://get.daocloud.io/daotools/set_mirror.sh | sh -s http://f1361db2.m.daocloud.io

## 安装Nginx

一行命令直接下载安装：如果本地没有nginx镜像会自动去中央仓库查找

> docker run --name nginx -d -p 80:80 nginx

### 验证是否成功

输入地址：http://服务器ip  如果出现nginx欢迎界面，便是成功

### 配置信息映射

安装成功后如果需要修改配置文件非常麻烦，所以需要将配置文件映射出来便于修改！！

先宿主机上创建文件夹用于映射

> mkdir -p /home/nginx/conf      存放配置文件
> mkdir -p /home/nginx/html		存放html
> mkdir -p /home/nginx/logs 		存放日志

复制一份配置文件

> docker cp nginx:/etc/nginx/nginx.conf /home/nginx/conf

移除启用的nginx

> docker stop nginx
> docker rm nginx

重新运行nginx
/usr/share/nginx/html   容器内部html文件地址
/etc/nginx/nginx.conf  容器内部配置文件
/var/log/nginx  容器内部nginx日志文件

```xml
docker run --name nginx -v /home/nginx/html:/usr/share/nginx/html -v /home/nginx/conf/nginx.conf:/etc/nginx/nginx.conf  -v /home/nginx/logs:/var/log/nginx -d -p 80:80 nginx
```

最后添加index.html到/home/nginx/html，然后再次访问网址即可发现成功了！！！
