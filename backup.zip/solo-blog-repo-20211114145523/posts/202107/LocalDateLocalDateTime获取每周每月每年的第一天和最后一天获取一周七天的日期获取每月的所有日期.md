title: LocalDate,LocalDateTime获取每周，每月，每年的第一天和最后一天，获取一周七天的日期，获取每月的所有日期
date: '2021-07-29 15:39:23'
updated: '2021-07-29 15:39:23'
tags: [LocalDateTime]
permalink: /articles/2021/07/29/1627544363904.html
---
![](https://b3logfile.com/bing/20181217.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

最近再弄日历相关的东西，然后就在获取每月所有日期，每周所有日期，每周，每月，每年的第一天和最后一天等，工具类没有这些方法，就写下来记录一下：


```
    /**
     * 一周的第一天
     *
     * @param localDate 当地日期
     * @return {@link LocalDate}
     */
    public static LocalDate firstDayOfWeek(LocalDate localDate){
        return localDate.with(DayOfWeek.MONDAY);
    }

    /**
     * 一周的最后一天
     *
     * @param localDate 当地日期
     * @return {@link LocalDate}
     */
    public static LocalDate lastDayOfWeek(LocalDate localDate){
        return localDate.with(DayOfWeek.SUNDAY);
    }

    /**
     * 月的第一天
     *
     * @param localDate 当地日期
     * @return {@link LocalDate}
     */
    public static LocalDate firstDayOfMonth(LocalDate localDate){
        return localDate.with(TemporalAdjusters.firstDayOfMonth());
    }

    /**
     * 月的最后一天
     *
     * @param localDate 当地日期
     * @return {@link LocalDate}
     */
    public static LocalDate lastDayOfMonth(LocalDate localDate){
        return localDate.with(TemporalAdjusters.lastDayOfMonth());
    }

    /**
     * 每年的第一天
     *
     * @param localDate 当地日期
     * @return {@link LocalDate}
     */
    public static LocalDate firstDayOfYear(LocalDate localDate){
        return localDate.with(TemporalAdjusters.firstDayOfYear());
    }

    /**
     * 每年的最后一天
     *
     * @param localDate 当地日期
     * @return {@link LocalDate}
     */
    public static LocalDate lastDayOfYear(LocalDate localDate){
        return localDate.with(TemporalAdjusters.lastDayOfYear());
    }


    /**
     * 每周的所有日期  即周一到周日
     *
     * @param localDate 当地日期
     * @return {@link List<LocalDate>}
     */
    public static List<LocalDate> allDaysOfWeek(LocalDate localDate){
        List<LocalDate> allDays=new ArrayList<>();
        allDays.add(localDate.with(DayOfWeek.MONDAY));
        allDays.add(localDate.with(DayOfWeek.TUESDAY));
        allDays.add(localDate.with(DayOfWeek.WEDNESDAY));
        allDays.add(localDate.with(DayOfWeek.THURSDAY));
        allDays.add(localDate.with(DayOfWeek.FRIDAY));
        allDays.add(localDate.with(DayOfWeek.SATURDAY));
        allDays.add(localDate.with(DayOfWeek.SUNDAY));
        return allDays;
    }

    /**
     * 每月的所有日期  即1日到31日
     *
     * @param localDate 当地日期
     * @return {@link List<LocalDate>}
     */
    public static List<LocalDate> allDaysOfMonth(LocalDate localDate){
        List<LocalDate> allDays=new ArrayList<>();
        LocalDate firstDayOfMonth = firstDayOfMonth(localDate);
        LocalDate lastDayOfMonth = lastDayOfMonth(localDate);
        allDays.add(firstDayOfMonth);
        int i = 1;
        LocalDate temp = firstDayOfMonth;
        while (!temp.isEqual(lastDayOfMonth)){
            LocalDate day = firstDayOfMonth.plusDays(i);
            allDays.add(day);
            temp=day;
            i++;
        }
        return allDays;
    }
```


### 如何获取农历日期，生肖，传统节日

[hutool工具包](https://www.hutool.cn/docs/#/core/%E6%97%A5%E6%9C%9F%E6%97%B6%E9%97%B4/%E5%86%9C%E5%8E%86%E6%97%A5%E6%9C%9F-ChineseDate)有相关的现成的工具包可以使用！！！！
