title: 前端技术知识点BUG资料博文(不断更新当中)
date: '2021-01-08 17:55:25'
updated: '2021-11-12 17:40:29'
tags: [vue, 前端技术]
permalink: /articles/2021/01/08/1610099724900.html
---
![](https://b3logfile.com/bing/20200505.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

最近自己在弄前端相关的一些东西，特此记录下在这个过程当中学习到的前端技术知识点和BUG处理方式

### VUE BUG以及知识点资料博文

1. [VUE 路由守卫 next() / next({ ...to, replace: true }) / next(‘/‘) 说明](https://blog.csdn.net/qq_41912398/article/details/109231418)
2. [vue通过路由跳转页面的三种方式](https://blog.csdn.net/qq_44388958/article/details/93925720)
3. [Missing required prop: “value” 报错的解决办法](https://blog.csdn.net/Yukinoshita_kino/article/details/107023315)
4. [element plus报错：Can&#39;t import the named export &#39;ArrowDown&#39; from non EcmaScript module (only default export is available)](https://blog.csdn.net/weixin_43518405/article/details/120299406) （2021-11-12 添加）

### JS BUG以及知识点资料博文

1 [JS判断数据类型的几种方式](https://blog.csdn.net/weixin_42259266/article/details/90028388)

2 [vscode中的 jsconfig.json](https://segmentfault.com/a/1190000018013282)  (2021-10-27添加)

### CSS BUG以及知识点资料博文

1 [CSS技巧（一）：清除浮动](https://www.cnblogs.com/ForEvErNoME/p/3383539.html)

2 [js判断页面图片是否存在，并设置默认值](https://blog.csdn.net/sinat_25926481/article/details/51378518)

3 [几个div在一行的三种方法](https://blog.csdn.net/weixin_30480075/article/details/98243322)

4 [rem与px的转换](http://caibaojian.com/rem-and-px.html)  （2021-10-20 添加）
