title: DOCKER安装MYSQL8.2.0版本
date: '2023-11-15 15:36:58'
updated: '2023-12-15 15:25:35'
tags: [mysql]
permalink: /articles/2023/11/15/1702545439826.html
---
记录下Docker下安装MySQL数据的操作

## 前言

在安装MYSQL之前首先需要安装DOCKER。

## 一条命令安装MySQL

```
docker run --name mysql --privileged=true  --restart always -v /home/mysql/data:/var/lib/mysql  -v /home/mysql/conf:/etc/mysql/conf.d -e MYSQL_ROOT_PASSWORD=123456 -p 3306:3306 -d mysql:8.2.0
```

### 命令解释

--name mysql  设置docker容器名称

--privileged=true  挂载文件权限设置

--restart always  设置 开机后自动重启容器

-v /home/mysql/conf:/etc/mysql/conf.d  挂载配置文件

-v /home/mysql/data:/var/lib/mysql   挂载数据文件 持久化到主机，

-e MYSQL_ROOT_PASSWORD=123456    设置数据库root账号密码

-p 3306:3306 端口映射

-d  mysql:8.2.0   后台启动mysql8.2.0版本

安装完毕后通过命令查看状态：

> docker   ps   可以查看容器的状态
>
> docker exec -it  mysql bash  可以进入mysql容器

### 注意事项

1 这里创建的root账号是可以直接远程访问，并没有限制只能本地访问，所以建议要么设置复杂一点，要么将远程访问的密码设置的复杂一点。

2 如果创建成功发现远程无法访问，看看服务器防火墙设置或者云服务器的安全组设置。

3 后续发现配置文件并没有生效，并且多次尝试均无法生效，只能使用命令设置相关配置信息  （不使用SET GLOBL 使用SET persist  然后重启容器即可）

> 例如：SET persist max_connections=50
