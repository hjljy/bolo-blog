title: Spring Cloud Alibaba 入门学习笔记第二篇：Nacos注册中心+Loadbalancer负载均衡
date: '2021-05-29 11:08:17'
updated: '2021-06-10 14:43:40'
tags: [springcloud, nacos, loadbalancer]
permalink: /articles/2021/05/29/1622257697431.html
---
![](https://b3logfile.com/bing/20200708.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

之前了解了springcloud alibaba，开始正式学习使用和搭建spring cloud项目，
版本信息：spring boot 2.5.0 + spring cloud 2020.0.2版 +spring cloud alibaba 2021.1版

## Nacos作为注册中心

[DUBBO2.7.x版本使用Nacos作为注册中心](https://www.hjljy.cn/articles/2020/01/07/1578397106684.html) 很早之前的nacos学习笔记，那时使用的是dubbo来构建的微服务。
在使用之前需要下载安装好nacos，见：[NACOS集群和单机模式启动](https://www.hjljy.cn/articles/2020/10/30/1604055510999.html)

接下来就是如何在springcloud当中使用nacos作为注册中心

### 创建服务A并注册到Nacos上

#### 创建服务

为避免麻烦，创建的时候全程点击next下一步即可，无需勾选任何的springboot相关jar。

#### 引入相关的JAR

完整pom文件如下

```
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>2.5.0</version>
        <relativePath/> <!-- lookup parent from repository -->
    </parent>
    <groupId>cn.hjljy.demo</groupId>
    <artifactId>springcloud</artifactId>
    <version>0.0.1-SNAPSHOT</version>
    <name>springcloud</name>
    <description>spring cloud nacos 注册中心</description>
    <properties>
        <java.version>1.8</java.version>
    </properties>
    <!--spring cloud 和spring cloud alibaba版本控制-->
    <dependencyManagement>
        <dependencies>
            <dependency>
                <groupId>org.springframework.cloud</groupId>
                <artifactId>spring-cloud-dependencies</artifactId>
                <version>2020.0.2</version>
                <type>pom</type>
                <scope>import</scope>
            </dependency>
            <dependency>
                <groupId>com.alibaba.cloud</groupId>
                <artifactId>spring-cloud-alibaba-dependencies</artifactId>
                <version>2021.1</version>
                <type>pom</type>
                <scope>import</scope>
            </dependency>
        </dependencies>
    </dependencyManagement>
    <dependencies>
        <!--        nacos 注册中心-->
        <dependency>
            <groupId>com.alibaba.cloud</groupId>
            <artifactId>spring-cloud-starter-alibaba-nacos-discovery</artifactId>
        </dependency>
        <!--        spring boot web 相关jar-->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
                <version>2.5.0</version>
            </plugin>
        </plugins>
    </build>
    <repositories>
        <repository>
            <id>central</id>
            <name>aliyun maven</name>
            <url>http://maven.aliyun.com/nexus/content/groups/public/</url>
            <layout>default</layout>
            <!-- 是否开启发布版构件下载 -->
            <releases>
                <enabled>true</enabled>
            </releases>
            <!-- 是否开启快照版构件下载 -->
            <snapshots>
                <enabled>false</enabled>
            </snapshots>
        </repository>
    </repositories>
</project>
```

#### 配置文件新增配置

```
spring.cloud.nacos.discovery.service=service-a
spring.cloud.nacos.server-addr=127.0.0.1:8848
server.port=8001
```

#### 创建测试服务接口

```java
@RestController
public class TestController {

    @GetMapping(value = "/echo/{string}")
    public String echo(@PathVariable String string) {
        return "Hello Im Service A " + string;
    }
}
```

#### 服务注册到nacos

在启动类上添加 @EnableDiscoveryClient

```java
/**
 * @author hjljy
 */
@SpringBootApplication
@EnableDiscoveryClient
public class ServiceAApplication {

    public static void main(String[] args) {
        SpringApplication.run(ServiceAApplication.class, args);
    }
}
```

#### 验证是否注册成功

先启动nacos ， 然后启动项目，最后进入nacos管理界面查看是否存在一个名为service-a的服务。存在就表示成功了。

![image.png](https://b3logfile.com/file/2021/05/image-ff115181.png)

### 关于服务调用

截止到2021.5.29日，Nacos无论是官方文档还是官方实例代码，进行服务调用都是使无法Robbion+RestTemplate。但是在spring cloud 2020版当中，官方移除了Robbion，所以按照官方示例文档进行调用会报错：java.net.UnknownHostException: service-a   无法找到service-a。所以这个时候就需要新的负载均衡器来进行调用了！！！

## Loadbalancer负载均衡调用

Spring Cloud Loadbalancer 就是新的官方推荐的负载均衡器。

### 创建服务B调用服务A

#### 创建服务和引入jar

和服务A的创建过程，POM文件一模一样，需要新增一个jar

```
    <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-loadbalancer</artifactId>
        </dependency>
```

#### 配置文件新增配置

```
spring.cloud.nacos.discovery.service=service-b
spring.cloud.nacos.server-addr=127.0.0.1:8848
server.port=8002
```

#### 开启服务发现和负载均衡

同样在启动类上添加 @EnableDiscoveryClient 然后在RestTemplate上面添加注解@LoadBalanced开启负载均衡，这样就可以通过服务名进行服务调用，无需用过IP+端口的方式进行调用

```
/**
 * @author hjljy
 */
@SpringBootApplication
@EnableDiscoveryClient
public class ServiceBApplication {
  

    @LoadBalanced
    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
    public static void main(String[] args) {
        SpringApplication.run(ServiceBApplication.class, args);
    }

}

```

#### 创建测试服务接口

```
@RestController
public class TestController {


    private final RestTemplate restTemplate;
  
    @Autowired
    public TestController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @GetMapping(value = "/echo/{string}")
    public String echo(@PathVariable String string) {
        return restTemplate.getForObject("http://service-a/echo/" + string, String.class);
    }
}
```

这里的service-a就是之前创建的服务A，无需使用IP+端口，直接使用服务名即可。

### 测试调用验证是否成功

1 启动nacos

2 启动服务A

3 启动服务B

4 浏览器输入  http://127.0.0.1:8002/echo/123456  如果正确返回 Hello Im Service A 123456 表示成功！！！

![image.png](https://b3logfile.com/file/2021/05/image-f54d864d.png)
