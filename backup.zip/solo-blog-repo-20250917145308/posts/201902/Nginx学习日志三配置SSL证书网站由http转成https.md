title: Nginx学习日志（三）配置SSL证书（网站由http转成https）
date: '2019-02-28 17:57:55'
updated: '2023-10-10 09:53:49'
tags: [Nginx]
permalink: /articles/2019/02/28/1551347168588.html
---
![](https://img.hacpai.com/bing/20180324.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# Nginx学习日志

[Nginx学习日志（一）简单入门](https://www.aliuying.com/articles/2019/01/16/1634873320001.html)
[Nginx学习日志（二）通过反向代理将不同域名映射到不同的端口](https://www.aliuying.com/articles/2020/02/01/1580571444782.html)

发现现在很多网站都变成了https，并且在浏览器当中如果是http类型的网站，还会提示网站不安全，所以打算将自己的博客换成https类型。
记录一下HTTP升级到HTTPS的过程。
网上看着很简单，但实际上还是遇到了不少的问题，不过还好，最终都一一解决了

# 什么是SSL证书？

> SSL证书是数字证书的一种，类似于驾驶证、护照和营业执照的电子副本。因为配置在服务器上，也称为SSL服务器证书。

参考资料：
https://yq.aliyun.com/articles/602965
https://www.sohu.com/a/225956682_596521

# 如何获取免费的SSL证书？

11种免费获取SSL证书的方式： https://www.toolmao.com/get-free-ssl （一篇非常详细的文章）
由于我是使用的阿里云服务器，所以是通过阿里云当中获取的免费SSL证书。

# nginx里面如何配置SSL证书?

由于我在阿里云服务器上的网站使用了Nginx，这里主要记录nginx的ssl证书配置过程。

## 配置过程

第一步： 将阿里云获取到的SSL证书下载下来。一般是两个文件：xxxx.pem 以及 xxxx.key
第二步： 在Nginx的安装目录下创建cert目录，并将下载的文件全部拷贝进去。
第三步： 修改nginx.conf配置信息
将原来的HTTP跳转重定向到https上面

```
server { 
	listen 80; 
	server_name aliuying.com,www.aliuying.com; 
	location / { 
		return 301 https://www.aliuying.com$request_uri;
		} 
	}
```

配置https的相关跳转

```
server {
        listen       443 ssl;
        server_name  www.aliuying.com;
		ssl on;
        ssl_certificate      ../cert/1864683_www.aliuying.com.pem;   #注意这里    指定第二步当中拷贝的文件位置
        ssl_certificate_key  ../cert/1864683_www.aliuying.com.key;
		ssl_session_timeout 5m;
 		ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:ECDHE:ECDH:AES:HIGH:!NULL:!aNULL:!MD5:!ADH:!RC4;
 		ssl_protocols TLSv1 TLSv1.1 TLSv1.2;
 		ssl_prefer_server_ciphers on;
        location / {
            	proxy_pass http://127.0.0.1:8081;   
        		proxy_set_header  Host $host:$server_port;
        		proxy_set_header  X-Real-IP  $remote_addr;
        	}
	}
```

第四步： 重启nginx 在安装目录bin下面输入：./nginx -s reload   报如下错误 因为安装nginx时未加载ssl模块
<font color=red size=3>nginx: [emerg] the "ssl" parameter requires ngx_http_ssl_module in /usr/local/nginx/conf/nginx.conf:84`</font>`
处理方式一：https://www.cnblogs.com/ghjbk/p/6744131.html
处理方式二：直接重新安装nginx 在安装时记得加载ssl模块支持。同时记得备份重要配置文件。
最后重启nginx就可以了。

# 问题总结

主要遇到了三个问题
第一个就是nginx未加载ssl模块报错的问题
第二个就是证书文件位置的问题
第三个花费时间最长，是属于自己的博客软件的问题。排查了很久才想到这个问题。
我使用的是[solo博客软件](https://solo.b3log.org/) 在软件初始化的时候，当时配置的网络地址是http类型的，导致在更换到https之后，部分静态资源无法获取到，存在资源降级的问题（就是开始是https的连接类型，然后里面有一些是http类型的连接，这部分的静态资源获取不到）。重新配置重启一下就好了。

# 参考资料

[Nginx/Tengine服务器安装SSL证书](https://help.aliyun.com/knowledge_detail/95491.html?spm=5176.2020520154.cas.25.4ecbqAMqqAMqjv)

