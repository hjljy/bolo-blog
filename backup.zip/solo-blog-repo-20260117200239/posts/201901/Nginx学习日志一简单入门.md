title: Nginx学习日志（一）简单入门
date: '2019-01-16 11:27:00'
updated: '2021-10-22 11:30:35'
tags: [Nginx]
permalink: /articles/2019/01/16/1634873320001.html
---
![](https://b3logfile.com/bing/20200905.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# Nginx是什么？

Nginx("engine x")是一款是由俄罗斯的程序设计师Igor Sysoev所开发高性能的 Web和 反向代理 服务器，也是一个 IMAP/POP3/SMTP 代理服务器。Nginx也可以作为反向代理进行负载均衡的实现
相关博文：[Nginx是什么？](https://www.cnblogs.com/wcwnina/p/8728391.html)

# Nginx在Linux下的安装

1. 安装编译工具及相关的库文件

   ```
    	yum -y install make zlib zlib-devel gcc-c++ libtool  openssl openssl-devel 
    	这句语句包含了Nginx所需要的核心工具和库文件。
   ```


- 安装PCRE
  yum install -y pcre pcre-devel
  我在进行安装的时候输入命令后提示已经安装了。![在这里插入图片描述](https://img-blog.csdnimg.cn/20190116174435827.png)
- 安装Nginx
  先下载Nginx压缩包 ：cd /usr/local/  （将压缩包下载到这个目录下）
  在目录当中输入：    wget http://nginx.org/download/nginx-1.8.0.tar.gz下载完毕之后解压安装包：         tar zxvf nginx-1.8.0.tar.gz
  然后进入安装包： cd nginx-1.8.0
  接着进行输入配置命令：./configure（使用默认的配置）
  最后输入安装命令：make   等待运行完毕 ，再输入make install
  到这里Nginx就安装完毕了，但是安装完毕后还需要启动
- 启动Nginx
  安装完毕之后会在local目录下产生一个nginx的目录：cd /usr/local/nginx/sbin
  然后启动Nginx就可以了：./nginx
- 在网页上输入对应的ip检测是否启动成功
- 如果能够看到nginx欢迎界面就表示成功了
- Nginx官网：http://nginx.org/
- 相关教学网站：http://www.runoob.com/linux/nginx-install-setup.html
- 相关博客：https://blog.csdn.net/qq_42815754/article/details/82980326
