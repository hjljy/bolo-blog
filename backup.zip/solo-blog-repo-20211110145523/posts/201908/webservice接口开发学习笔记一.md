title: webservice接口开发学习笔记（一）
date: '2019-08-14 16:29:07'
updated: '2019-08-14 16:29:07'
tags: [webservice]
permalink: /articles/2019/08/14/1565771346992.html
---
![](https://img.hacpai.com/bing/20180803.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)


# 前言
有一段时间没有好好学习了，因为遇到一些糟心的事情，上班一直在划水摸鱼,本来打算摸鱼摸到事情尘埃落定。但想到与其摸鱼，还不如多学习点东西，不断的成长提升自己。
# webservice简介
webservice:一种跨语言和跨平台的远程调用技术，即JAVA应用程序可以通过websrvice调用PHP或者Python等程序提供的服务，反之亦然。
实现一个webservice需要了解它的几个重要点（SOAP,WSDL,UDDI）
## SOAP
简单来说： SOAP = HTTP + XML  就是一个简单的数据交换协议
客户端通过发送一个HTTP请求，这个HTTP请求里面包含一个XML，服务端接收到请求后解析这个XML然后来调用对应的服务和方法，返回对应的数据。
## WSDL
简单来说：WSDL就是告诉调用者应该怎么填写SOAP当中的XML文件里面的内容。服务端具体提供了什么服务，该怎么调用这个服务，该传递什么类型的参数。会返回什么类型的数据等等。
## UDDI
简单来说：UDDI是用于描述、发现、集成Web Service的技术。

# webservice相关框架

 - JWS：JAVA语言对WebService服务的一种实现，可以用于开发以及发布webservice服务。
 - Axis2：一个重量级的webservice框架，功能强大。
 - CXF：一个基于XFire改造后的webservice框架，高性能，开发比较方便。
 
# webservice接口和http接口的区别
 > web service相对http (post/get)
            1.接口中实现的方法和要求参数一目了然
            2.不用担心大小写问题
            3.不用担心中文urlencode问题
            4.代码中不用多次声明认证(账号,密码)参数
            5.传递参数可以为数组，对象等...
            6.由于要解析XML，效率相对较慢。
            7.在对参数要求不严谨的情况下完全可以由HTTP请求代替。
# 一个简单的webservice服务
通过JAVA自带的JWS发布一个webservice服务。
## 客户端代码：

1 在类上加上注解：@webservice表明这是一个webservice服务
```
@WebService
public class DemoWebServiceImpl {
    @Override
    @WebMethod
    public String getName(Integer code) {
        if(code==1){
            return "张三";
        }
        return "李四";
    }
}
```
2 通过Endpoint 发布一个webservice服务。

```
   public static void main(String[] args) {
        //设置webservice地址
        String address = "http://192.168.15.234:9090/webservice";
        //发布webservice
        Endpoint.publish(address , new DemoWebServiceImpl());
        System.out.println("hello world");
    }
```
3 在浏览器当中输入地址：http://192.168.15.234:9090/webservice?wsdl 如果返回一个xml就表明发布成功了。
在返回的xml当中每个方法对应一个XSD地址。在浏览器当中输入对应的xsd地址就可以看到该方法需要的参数和返回的值类型。
## 服务端调用：
通过测试工具SOAPUI进行模拟调用。创建对应soap，然后找到方法，设置参数，发送请求就可以了。
![图片.png](https://img.hacpai.com/file/2019/08/图片-ec6d0309.png)
![图片.png](https://img.hacpai.com/file/2019/08/图片-cedb9c21.png)


一个简单的webservice服务就搞定了。