title: 盘点下那些开源的优秀markdown插件
date: '2021-12-24 11:39:01'
updated: '2021-12-24 11:39:01'
tags: [markdown]
permalink: /articles/2021/12/24/1640317140995.html
---
![](https://b3logfile.com/bing/20210622.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

最近在弄自己的博客项目，现在写博客基本都是使用的markdown，所以一个好的markdown插件就很重要了。整理下自己在网上查找到的一些优秀的markdown插件。

| 插件名称     | 官方地址                                                         | md基础功能 | 支持@[toc]目录 | 编辑模式                             | 主题切换 | 维护情况     |
| ------------ | ---------------------------------------------------------------- | ---------- | -------------- | ------------------------------------ | -------- | ------------ |
| mavonEditor  | http://www.mavoneditor.com/                                      | 支持       | 支持           | 分屏预览                             | 不支持   | 目前维护当中 |
| md-editor-v3 | https://imzbf.github.io/md-editor-v3/index                       | 支持       | 不支持         | 分配预览                             | 支持     | 目前维护当中 |
| Editor.md    | https://pandao.github.io/editor.md/                              | 支持       | 支持           | 分配预览                             | 不支持   | 当前维护堪忧 |
| vue-markdown | https://zhaoxuhui1122.github.io/vue-markdown-docs/changelog.html | 支持       | 不支持         | 分配预览                             | 不支持   | 目前维护当中 |
| vditor       | https://b3log.org/vditor/                                        | 支持       | 不支持         | 分屏预览，所见即所得，<br />及时渲染 | 支持     | 当前维护当中 |
