title: POSTGRESQL  数据库使用注意事项
date: '2021-04-27 11:52:44'
updated: '2021-09-22 15:39:59'
tags: [PostgreSql]
permalink: /articles/2021/04/27/1619495564641.html
---
![](https://b3logfile.com/bing/20201122.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# POSTGRESQL  数据库使用注意事项

最近公司项目使用的是POSTGRESQL  数据库，之前一直没有接触过，特此记录下使用过程当中遇到的问题和处理方式。

### 1 POSTGRESQL 表字段顺序修改

处理方式：没有什么较好的方式，放弃了。

### 2 POSTGRESQL 修改列数据类型报错：CANNOT BE CAST SMALLINT TO TYPE BOOLEAN

处理方式：先将数据类型修改为：varchar  然后修改为bool   注意 bool当中t表示true ，f表示false

### 3 POSTGRESQL 远程链接经常掉线

处理方式：修改数据库配置文件的以下配置   相关文章：[PG数据库(Postgresql)解决远程易掉线问题](https://blog.csdn.net/yanzhaoxun/article/details/112680264)

> `tcp_keepalives_idle = 20` #20秒主动发心跳
> `tcp_keepalives_interval = 10` #10秒未收到返回心跳则本心跳失败
> `tcp_keepalives_count = 3` #连续3次心跳失败则主动断线
