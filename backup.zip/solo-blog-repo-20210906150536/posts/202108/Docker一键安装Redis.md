title: Docker 一键安装Redis
date: '2021-08-05 14:16:39'
updated: '2021-08-05 14:16:39'
tags: [redis, docker]
permalink: /articles/2021/08/05/1628144199134.html
---
![](https://b3logfile.com/bing/20190905.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

记录下Docker 安装redis的快捷命令！！！

```linux
docker run --restart=always -p 6379:6379 --name redis -v /home/redis/redis.conf:/etc/redis/redis.conf -v /home/redis/data:/data -d redis redis-server /etc/redis/redis.conf  
```

命令说明：

1. --restart=alaways   开启自启动
2. -p 6379:6379  将主机的6379端口和容器的6379进行绑定映射
3. --name redis  将容器命名为redis
4. -v /home/redis/redis.conf:/etc/redis/redis.conf  将物理机上面/home/redis/redis.conf文件映射到容器内部/etc/redis/redis.conf
5. -v /home/redis/data:/data 将物理机上的/home/redis/data文件夹映射到容器内部/data文件夹 用于保存数据
6. -d redis 表示后台启动redis镜像（如果本地没有redis镜像就从docker仓库里面拉取）
7. redis-server /etc/redis/redis.conf 表示启动redis的时候以配置文件启动，由于上面将物理机上面/home/redis/redis.conf文件映射到容器内部/etc/redis/redis.conf 所以最终找到的是物理机上的/home/redis/redis.conf

### 如何获取redis.conf配置文件？

直接上官方网址，下载redis，然后拷贝里面的redis.conf文件即可

### 如何进入容器内部并且使用客户端链接上redis

物理机上输入 docker exec -it redis redis-cli 即可！！！

### 安装完毕后，如何修改配置文件并生效？

直接修改上面的/home/redis/redis.conf文件的内容，然后重启容器即可 docker restart redis

### 开启远程访问，AOF持久化以及设置密码

修改配置文件里面的内容
#bind 127.0.0.1   注释掉  就可以开启远程访问
appendonly yes  yes表示开启AOF持久化 no表示关闭 （默认是开启的RDB，如果要关闭RDB  注释掉 save 开头的配置）
appendfilename "appendonly.aof"  持久化文件的名称 持久化后会在/data目录创建一个持久化文件
requirepass  password 设置密码为password

### redis 常用参数说明

> #是否作为守护进程运行 yes 或者 no
> daemonize  yes
> #监听IP,redis一般监听127.0.0.1 网段访问，集群模式需要指定IP地址。如果需要外网访问需要注释
> bind 192.168.1.115
> #指定存储Redis进程号的文件路径
> pidfile/var/run/redis.pid
> #端口
> port 6379
> #TCP 监听的最大容纳数量
> tcp-backlog 511
> #客户端和Redis服务端的连接超时时间，默认是0，表示永不超时。
> timeout 0
> #tcp心跳时间
> tcp-keepalive 0
> #日志记录等级，4个可选值debug,verbose,notice,warning
> loglevel notice
> #配置 log 文件地址,默认打印在命令行终端的窗口上，也可设为/dev/null屏蔽日志、
> ogfile"/opt/redis/logs/redis-6379.log"
> #可用的数据库数，默认值为16，默认数据库为0
> databases 16
> #RDB保存策略，900秒存在一个Key变动或者300秒10个key或者60秒1000000变动就保存一次
> save 900 1
> save 300 10
> save 60 10000000
> #redis 保存失败后，redis 将停止接受写操作，
> stop-writes-on-bgsave-error yes
> #在进行备份时,是否进行压缩
> rdbcompression yes
> #读取和写入的时候是否支持CRC64校验，默认是开启的
> rdbchecksum yes
> #备份文件的文件名
> dbfilename dump.rdb
> 备份文件地址
> dir ./
> 内存淘汰策略 默认为noeviction ,即没有淘汰策略,直接返回错误给客户端
> maxmemory-policy noeviction
> #volatile-lru :利用lru算法淘汰设置过过期时间的key
> #allkeys-lru :利用lru算法淘汰所有的key
> #olatile-random :随机的淘汰设置过过期时间的key
> #allkeys-random :随机的淘汰所有的keyvolatile-ttl :淘汰即将到达过期时间的key
> #noeviction :没有淘汰算法
> #AOF持久化开启 默认为no
> appendonly no
> #文件名称
> appendfilename"appendonly.aof"
> #设置对 appendonly.aof 文件进行同步的频率,有三种选择always、everysec、no，默认是everysec表示每秒同步一次。
> appendfsync everysec
> #一个Lua脚本最长的执行时间，单位为毫秒，如果为0或负数表示无限执行时间，默认为5000
> lua-time-limit 5000
> 设置redis访问密码 默认无需密码
> requirepass  password 设置密码为password
>
