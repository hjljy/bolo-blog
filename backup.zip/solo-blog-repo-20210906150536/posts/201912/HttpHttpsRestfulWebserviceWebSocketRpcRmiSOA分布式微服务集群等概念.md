title: Http,Https,Restful,Webservice,WebSocket,Rpc,Rmi,SOA,分布式,微服务,集群等概念
date: '2019-12-26 15:38:30'
updated: '2019-12-26 15:38:30'
tags: [JAVA]
permalink: /articles/2019/12/26/1577345910587.html
---
![](https://img.hacpai.com/bing/20190710.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


## 前言

在JAVA开发学习过程当中,总是会接触到很多概念性的名词。特此简单的总结记录一下相关名词对应的概念。

## HTTP协议和HTTPS协议，RESTFUL接口
HTTP协议：是Hyper Text Transfer Protocol（超文本传输协议）的缩写，这是非常常见的一种协议，简单来说就是一个无状态的基于TCP/IP协议实现的应用层协议。

HTTPS协议：
由于HTTP协议的安全性问题而出现的协议，可以理解成**HTTP + 加密 + 认证 + 完整性保护 = HTTPS**  
通常表现为：HTTP+SSL/TLS=HTTPS。
PS:(现在打开一个网站，如果不是以https开头，而是以http开头的话，浏览器基本都会提示你网站不安全什么的！！！)

RESTFUL：简单来说就是对HTTP请求的方式和路径的一种约束规则，一种思想。  只要是符合这种思想的HTTP接口都可以叫做RESTFUL接口
即同一个路径，相同的参数，请求方式的不同,得到的结果也就不一样。

相关资料：
[关于HTTP协议，一篇就够了](https://www.jianshu.com/p/80e25cb1d81a)
[HTTP和HTTPS协议，看一篇就够了](https://blog.csdn.net/xiaoming100001/article/details/81109617)
[RESTful介绍和使用教程](https://blog.csdn.net/x541211190/article/details/81141459)

## WebSocket  
WebSocket：简单来说就是一个基于TCP的持久化网络通信协议。  WebSocket和Http有关系，但是不是Http协议。
其主要作用就是：服务端可以主动推送信息给客户端，不需要客户端重复的向服务端发请求查询。  
  
相关资料：[WebSocket 是什么原理？为什么可以实现持久连接？](https://www.zhihu.com/question/20215561)

## Webservice
Webservice：一种跨语言和跨平台的远程调用技术，即JAVA应用程序可以通过websrvice调用PHP或者Python等程序提供的服务，反之亦然。  其使用的是SOAP协议。
SOAP = HTTP + XML  
即客户端通过发送一个HTTP请求给服务端，这个HTTP请求里面包含一个XML，服务端接收到请求后解析这个XML里面的数据，然后来调用对应的服务和方法，最后返回对应的数据给客户端。

WebService和Restful之间的区别和联系？
相同点：都是基于HTTP协议传输数据。
不同点：传输数据的格式不同，webservice是通过xml传输，对数据格式的要求相对严格！Restful基本是通过Json格式传输数据。
相关资料：[webservice接口开发学习笔记](https://www.hjljy.cn/articles/2019/08/14/1565771346992.html)

## RPC和RMI
RPC：**Remote Procedure Call** 翻译过来就是 **远程过程调用**。
如何理解RPC？
简单来说就是 客户端通过HTTP,TCP/IP等协议将数据传给服务端，然后服务端通过对应的协议解析数据，然后执行对于的方法，并将结果通过对应的协议返回给客户端，是一种思想，一种解决方式。
RMI：就是用JAVA实现的RPC，只能在Java语言当中使用。

相关资料：[如何给老婆解释什么是RPC](https://www.jianshu.com/p/2accc2840a1b) 

RPC和webservice的区别？
相同点：都是客户端将数据传给服务端，然后服务端解析数据，执行方法，返回结果。
不同点：
1.  传输数据的协议或者说方式不同。RPC传输数据的方式多种多样，Webservice都是通过HTTP协议。
1.  主要使用场景不一样。RPC主要是用于系统内部不同服务之间的服务调用，webservice主要是用于调用其他系统的服务或者提供给外部系统调用。通常对外提供服务接口基本上都是：webservice接口，http接口（包含符合restful风格的HTTP接口），MQ接口（相对较少）等等。

相关资料：[RPC体系,RPC和WebService的区别详解](https://www.jianshu.com/p/209f89b39b9d)


## API和SDK
经常在开发当中听到SDK和API这两个名词。
SDK：软件开发工具包 就相当于一个utils工具类
API ：软件开发工具包的使用说明文档。  

相关资料：[SDK和API最通俗的解释]([https://baijiahao.baidu.com/s?id=1631565855082549763](https://baijiahao.baidu.com/s?id=1631565855082549763&wfr=spider&for=pc))

## SOA和微服务
>SOA是一种设计方法，其中包含多个服务，而服务之间通过配合最终会提供一系列功能。一个服务通常以独立的形式存在于操作系统进程中。服务之间通过网络调用，而非采用进程内调用的方式进行通信。

>微服务是一种架构风格，一个大型复杂软件应用由一个或多个微服务组成。系统中的各个微服务可被独立部署，各个微服务之间是松耦合的。每个微服务仅关注于完成一件任务并很好地完成该任务。在所有情况下，每个任务代表着一个小的业务能力

区别和联系？
没有接触过SOA架构，不是很清楚两者之间的区别和联系！

微服务和RPC的联系？

通常在系统当中，各个微服务之间的通信都是通过RPC框架来实现的！！！
常见的RPC框架：DUBBO，Spring Cloud，Thrift（可以跨语言！！！）。


相关资料：
[什么是微服务？一篇文章让你彻底搞明白](https://blog.csdn.net/zmbaliqq/article/details/84936551)
[微服务架构 vs. SOA架构](https://www.cnblogs.com/jiangzhaowei/p/9168837.html)
## 分布式和集群，负载均衡

分布式：一个大系统拆成很多小系统部署在不同的机器上。
集群：一个系统在多台机器上部署。
负载均衡：集群环境下才会存在负载均衡，将对同一个系统的访问根据相关策略分配到不同的机器上。

相关资料：[菜鸟教你如何通俗理解——>集群、负载均衡、分布式](https://blog.csdn.net/zhou2s_101216/article/details/51707270)