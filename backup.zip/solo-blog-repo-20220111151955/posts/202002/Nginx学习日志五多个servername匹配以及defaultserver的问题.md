title: Nginx学习日志（五）多个server_name匹配以及default_server的问题
date: '2020-02-22 22:43:21'
updated: '2021-09-22 15:44:41'
tags: [Nginx]
permalink: /articles/2020/02/22/1582382601602.html
---
![](https://img.hacpai.com/bing/20180918.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## nginx 多个 server_name 如何匹配？

简单看这个问题，会觉得这个问题很蠢，怎么匹配？不就是根据 server_name 名字匹配的么？

是的，我最开始也是这么觉得的，并且在之前的笔记：[Nginx学习日志（二）通过反向代理将不同域名映射到不同的端口](https://www.hjljy.cn/articles/2020/02/01/1580571444782.html)  当中的记录也是根据名字匹配。

但是当我新解析一个域名：blog.hjljy.cn 到服务器上面的时候， nginx server_name 里面还没有来得及配置这个域名只配置了：www.hjljy.cn 这个域名，这时在浏览器输入 blog.hjljy.cn  这个域名，按照上面的想法应该是找不到服务器的。而事实的结果是尽管访问的是 blog.hjljy.cn 但是最终跳转到了 www.hjljy.cn   。

然后在 nginx 配置了多个 server_name ,访问对应的域名都可以跳转到对应的域名服务上去，情况符合之前写的笔记：[Nginx学习日志（二）通过反向代理将不同域名映射到不同的端口](https://www.hjljy.cn/articles/2020/02/01/1580571444782.html)   。

但是当我又新解析一个域名：api.hjljy.cn 到服务器上面的时候， 发现访问这个 api.hjljy.cn,还是会跳转到 www.hjljy.cn 上面去。

最终经过多次尝试和查阅资料得到以下的结论：

1  确实是通过 server_name 进行匹配然后转发请求的
2  如果没有匹配的 server_name，会默认跳转到 default_server 去 然后由 default_server 处理这个请求。
3  如果有匹配的 server_name  但是在这个 server 里面没有这个请求的处理方式的话，也会默认跳转到 default_server 去。
例如：  blog.hjljy.cn  只配置了下面的请求处理方式。  当我的请求为： blog.hjljy.cn/501.html 并且对应的请求能够正常转发就可以正常进入  但是如果是 blog.hjljy.cn/401.html  就会跳转到 www.hjljy.cn/401.html

> location = /50x.html {
> root   /usr/local/nginx/html/myerror;
> }

## default_server 的问题

显示指定

```java
listen 80  default_server;
```

不显示指定的话，默认第一个 server_name

参考：https://www.oschina.net/question/12_3565   算是一种对于不匹配的请求的处理方式，虽然我现在没有用，不过可以记录下来方便以后可能用到。

```
server {
    listen       80  default_server;
    server_name  _;
    return       404;
}
```
