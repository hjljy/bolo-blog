title: SpringBoot学习日志之发送邮件和SMS短信
date: '2020-01-06 16:08:18'
updated: '2021-09-22 15:44:07'
tags: [sms, springboot]
permalink: /articles/2020/01/06/1578298098484.html
---
![](https://img.hacpai.com/bing/20180718.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 前言

账号注册的时候通常会选择短信注册或者邮箱注册，那么如何在JAVA当中实现短信的发送和邮件的发送呢？

## SMS服务实现

发送短信通常都是接入第三方的SMS服务，例如：阿里云SMS，百度云SMS，七牛云SMS等等。但是上面的都要钱，虽然不多。

不过腾讯云注册会送100条免费短信。所以作为一名个人开发者直接使用腾讯云的进行测试就可以了。实际开发的话，根据情况在进行选择就可以。

阿里云SMS接入指南：[如何接入阿里云短信服务 （完整指南）](https://yq.aliyun.com/articles/252987)
百度云SMS官方接入指南：[简单消息服务快速入门](https://cloud.baidu.com/doc/SMS/s/vjwvxrrl8)
腾讯云SMS官方接入指南：[官方文档API](https://cloud.tencent.com/document/product/382/13297#.E7.9F.AD.E4.BF.A1-api)

这种接入第三方SDK开发的，还是要好好的去看看官方文档，根据官方文档进行操作一般不会出问题！

## 发送邮件实现

重要事项：一定要开启邮箱的SMTP服务！！！获得对应的授权码
重要事项：一定要开启邮箱的SMTP服务！！！获得对应的授权码
重要事项：一定要开启邮箱的SMTP服务！！！获得对应的授权码

以QQ邮箱为例：在邮箱设置--账户--POP3/IMAP/SMTP/Exchange/CardDAV/CalDAV服务 里面开启SMTP服务获取授权码。

### 普通Java项目发送邮件

```java
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;

/**
 * @author hjljy@outlook.com
 * @date 2020/1/6 15:39
 * @apiNote //TODO
 */
public class SenderEmail {
    public static void main(String[] args) throws Exception {
        Properties properties = new Properties();
        // 连接协议
        properties.put("mail.transport.protocol", "smtp");
        // 主机名
        properties.put("mail.smtp.host", "smtp.qq.com");
        // 端口号
        properties.put("mail.smtp.port", 25);
        //开启权限校验
        properties.put("mail.smtp.auth", "true");
      
      
        // 得到回话对象
        Session session = Session.getInstance(properties);
        // 获取邮件对象
        Message message = new MimeMessage(session);
        // 设置发件人邮箱地址
        message.setFrom(new InternetAddress("921244819@qq.com"));
        // 设置收件人邮箱地址
        message.setRecipients(Message.RecipientType.TO, new InternetAddress[]{new InternetAddress("hjljy@outlook.com")});
        // 设置邮件标题
        message.setSubject("xmqtest");
        // 设置邮件内容
        message.setText("邮件内容邮件内容邮件内容xmqtest");
        // 得到邮差对象
        Transport transport = session.getTransport();
        // 连接自己的邮箱账户
        transport.connect("921244819@qq.com", "password");// 密码为QQ邮箱开通的stmp服务后得到的客户端授权码
        // 发送邮件
        transport.sendMessage(message, message.getAllRecipients());
        transport.close();
    }
}
```

### Springboot项目发送邮件

第一步：在springboot项目当中引入对应JAR

```xml
  <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-mail</artifactId>
  </dependency>
```

第二步：在application当中配置相关参数

```xml
# 设置是否需要认证，如果为true,那么用户名和密码就必须的，大多数平台都要求必须
spring.mail.properties.mail.smtp.auth=true

# 设置用户名
spring.mail.username=921244819@qq.com

# 设置密码，该处的密码是QQ邮箱开启SMTP的授权码而非QQ密码
spring.mail.password=password

# 设置邮箱主机
spring.mail.host=smtp.qq.com
spring.mail.port=25
```

第三步：编写测试代码

```java
@SpringBootTest
class SmsEmailDemoApplicationTests {

    @Autowired
    JavaMailSenderImpl javaMailSender;

    @Test
    void contextLoads() {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom("921244819@qq.com");
        message.setTo("hjljy@outlook.com");
        message.setSubject("邮件主题");
        message.setText("邮件内容信息测试");
        javaMailSender.send(message);
    }
}
```

### 登陆hjljy@outlook.com查看结果

![图片.png](https://img.hacpai.com/file/2020/01/图片-83a26c13.png)

总的来说代码简单。邮件方面如果要实现附件，图片这类也有相关的API，调用对应的API就行了。
