title: varchar(20)和varchar(255)的区别，数据库表字段长度设计学习
date: '2019-05-21 00:02:49'
updated: '2019-05-21 00:02:49'
tags: [mysql]
permalink: /articles/2019/05/21/1558368169678.html
---
![](https://img.hacpai.com/bing/20180312.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 学习原因
在开发当中，经常看见有些字段长度是varchar(20)或者varchar(32)，但是在自己建表的时候，navicat基本上都是默认的varchar(255)的长度。
所以带着疑问来学习一下数据库表字段长度的设计。

# 长度限制和字段选择
查阅了资料后，发现了一些关于数据库的长度限制及表设计的相关资料

> 相关资料： 
[各个数据库表名和字段名长度限制](http://blog.itpub.net/205377/viewspace-2132648/)
[MySQL中各种数据类型的长度及在开发中如何选择](http://www.cnblogs.com/waliwaliwa/p/6891453.html)
[MySql数据库表字段命名及设计规范](https://blog.csdn.net/chl191623691/article/details/78247497/)
[数据库中存储日期的字段类型到底应该用varchar还是datetime](https://blog.csdn.net/u013905744/article/details/72628046/)
[为什么很多公司要求 mysql 表主键 id 必须是 long 型？](https://www.v2ex.com/t/288290)
[为什么mysql的varchar字符长度会被经常性的设置成255](https://blog.csdn.net/w790634493/article/details/80650611)

在仔细阅读上述的相关资料后，算是解决了很多的疑问，也学习到了不少数据库书本上难以学习到的经验。
总的来说就是数据库表名和字段长度是有一个限制的，不是越大就好，在设计创建表字段时也要考虑下字段长度问题，根据一些实际情况选择表当中的字段类型和手动设置一下字段的长度，可以对数据的维护，查询带来效率和性能上的提升。


# 验证varchar(20)和varchar(255)的区别
关于这个问题，也在网上找了很多的资料进行查看，既然是学习嘛，光看是没有什么意思的，还是要动手验证一下。

> 相关资料：
> [varchar(500)比varchar(8000)更有优势吗？](https://oomake.com/question/407339)
> [MySQL中采用类型varchar(20)和varchar(255)对性能上的影响](https://blog.csdn.net/jirongzi_cs2011/article/details/41983393)

创建一个测试表，并创建相关的字段，存入1000条数据。具体操作如下

```
CREATE TABLE ABC (
  id int(11) DEFAULT NULL,
  name varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8; -- 创建表
ALTER  TABLE  ABC  ADD  INDEX nameIndex (name);  -- 给name 字段添加索引
explain select name from ABC;    --  分析这个查询sql语句
```
结果如下图：
![图片.png](https://img.hacpai.com/file/2019/05/图片-ee131ff8.png)
![在这里插入图片描述](https://img-blog.csdnimg.cn/2019052023400195.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3ljZjkyMTI0NDgxOQ==,size_16,color_FFFFFF,t_70)
可以看到此时的KEY_LEN为63
然后往表里面存1000条数据，直接复制粘贴1000条一样的数据用于测试，查看表空间大小

```
SELECT CONCAT(TRUNCATE(SUM(data_length),2),'B') AS data_size,
CONCAT(TRUNCATE(SUM(max_data_length),2),'B') AS max_data_size,
CONCAT(TRUNCATE(SUM(data_free),2),'B') AS data_free,
CONCAT(TRUNCATE(SUM(index_length),2),'B') AS index_size
FROM information_schema.tables WHERE TABLE_NAME = 'ABC';
```
结果如下图：
![图片.png](https://img.hacpai.com/file/2019/05/图片-b51eeaae.png)
可以看见：data_size的值为：16384
然后修改字段name的长度为255，再次查看key_len和data_size的值

```
alter table ABC  modify name varchar(255);
explain select name from ABC;
SELECT CONCAT(TRUNCATE(SUM(data_length),2),'B') AS data_size,
CONCAT(TRUNCATE(SUM(max_data_length),2),'B') AS max_data_size,
CONCAT(TRUNCATE(SUM(data_free),2),'B') AS data_free,
CONCAT(TRUNCATE(SUM(index_length),2),'B') AS index_size
FROM information_schema.tables WHERE TABLE_NAME = 'ABC';
```
结果如下：
KEY_LEN变成了768  但是data_size没有变化。
验证完毕：得出结论,通常情况下使用varchar(20)和varchar(255)占用的空间都是一样的,但是使用索引长度有所不同。所以在设计时尽量保持一个合理的长度范围。

# 额外的发现
在测试当中还有一个些的发现：表字段的类型其实是有长度限制，int类型最大为255等等。
一个表，所有字段的长度加起来不能超过65535字节，是字节不是字符 。不包括text blob类型的字段。