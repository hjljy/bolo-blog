title: Springboot之swagger-bootstrap-ui(knife4j)
date: '2020-06-05 16:12:52'
updated: '2020-06-05 16:14:20'
tags: [springboot, swagger, knife4j]
permalink: /articles/2020/06/05/1591344771998.html
---
![](https://img.hacpai.com/bing/20200516.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

最近在网上看到一个比较好的swagger-ui,swagger自带的UI不是很友好。特此记录下整合过程，并梳理下swagger相关的知识

## 什么是swagger?

简单来说就是解放程序员，让程序员少些不必要的API文档，只需要在项目当中定义好接口，返回实体等然后通过swagger暴露出来就可以自动生成接口相关的API文档！！！

## swagger-bootstrap-ui(knife4j)

swagger是由自己自带的UI的，不过在对比两个之后，感觉swagger-bootstrap-ui现已变更为knife4j很不错！！！[knife4j官网](https://doc.xiaominfo.com/)
第一步：引入JAR包

```xml
        <dependency>
            <groupId>io.springfox</groupId>
            <artifactId>springfox-swagger2</artifactId>
            <version>2.9.2</version>
        </dependency>
        <dependency>
            <groupId>com.github.xiaoymin</groupId>
            <artifactId>knife4j-spring-boot-starter</artifactId>
            <version>2.0.3</version>
        </dependency>
```

第二步：代码开启swagger2支持

```java
@Configuration
@EnableSwagger2 
public class Swagger2Configuration {


    @Bean
    public Docket createRestApi() {

        List<Parameter> pars = new ArrayList<Parameter>();
  
        //构建默认参数
        ParameterBuilder ticketPar = new ParameterBuilder();
        ticketPar.name("Content-Type").description("Content-Type")
                .modelRef(new ModelRef("string")).parameterType("header")
                .required(true)
                .defaultValue("application/json").build();
        pars.add(ticketPar.build());
        //构建默认请求验证参数
        ticketPar = new ParameterBuilder();
        ticketPar.name("Authorization").description("Authorization")
                .modelRef(new ModelRef("string")).parameterType("header")
                .required(true)
                .defaultValue("111111111111111111111111111111111111111111111111").build();
        pars.add(ticketPar.build());
  
        return new Docket(DocumentationType.SWAGGER_2)
                .apiInfo(apiInfo())
                .select()
                .apis(RequestHandlerSelectors.basePackage("cn.hjljy.fastboot.controller"))
                .paths(PathSelectors.any())
                .build()
                .globalOperationParameters(pars);
    }

    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title("swagger RESTful APIs")
                .description("swagger RESTful APIs")
                .termsOfServiceUrl("http://www.hjljy.cn/")
                .contact("hjljy@outlook.com")
                .version("1.0")
                .build();
    }


}
```

第三步：创建一个Controller接口，然后输入：127.0.0.1:8080/doc.html 然后就可以在浏览器当中看到接口数据了。

## swagger注解说明

@Api(tags = "测试管理")  用于controller类表明类的接口

@ApiOperation(value = "测试接口")  用于方法上面 表明方法作用

@ApiModel(value = "demo")  用于实体类上，表明实体类的作用

@ApiModelProperty(value = "名称",required = true)  用于实体类字段上面，表明字段代表含义

其它略。。。。
