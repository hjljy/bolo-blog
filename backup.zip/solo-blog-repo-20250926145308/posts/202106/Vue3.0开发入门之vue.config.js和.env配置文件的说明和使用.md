title: Vue3.0开发入门之vue.config.js和.env配置文件的说明和使用
date: '2021-06-10 17:41:31'
updated: '2021-06-10 17:41:51'
tags: [vue]
permalink: /articles/2021/06/10/1623318091354.html
---
![](https://b3logfile.com/bing/20171219.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## Vue3.0开发入门之vue.config.js和.env配置文件的说明和使用

### 第一步搭建Vue3.0项目

见文章：[vue3.0脚手架搭建](https://blog.csdn.net/xiongdaandxiaomi/article/details/107034863)

### vue.config.js

vue.config.js 是全局 CLI 配置文件，如果项目的 (和 package.json 同级的) 根目录中存在这个文件，那么它会被 @vue/cli-service 自动加载。
官方具体说明地址：https://cli.vuejs.org/zh/config/#%E5%85%A8%E5%B1%80-cli-%E9%85%8D%E7%BD%AE

### .env文件

.env文件主要用于存储环境变量
官方说明地址：https://cli.vuejs.org/zh/guide/mode-and-env.html#%E7%8E%AF%E5%A2%83%E5%8F%98%E9%87%8F
其他说明资料：https://www.cnblogs.com/-pdd/p/14718514.html

### 注意点

1 默认情况下，调用vue-cli-service serve  会查找development的配置文件  vue-cli-service build会查找production的配置文件，无需进行额外的指定
2 配置文件的参数除了特定的，其他的开头尽量设置为：VUE_APP_
