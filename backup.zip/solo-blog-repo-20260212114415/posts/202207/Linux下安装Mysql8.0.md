title: Linux下安装Mysql8.0
date: '2022-07-02 18:05:01'
updated: '2022-07-02 18:05:01'
tags: [mysql, linux]
permalink: /articles/2022/07/02/1656756301397.html
---
![](https://b3logfile.com/bing/20200430.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 前提

在安装之前需要判断是否已经安装过mysql 方式很多，自行百度

```linux
[root@localhost ~]# yum list installed mysql*

[root@localhost ~]# rpm –qa|grep mysql*
```

## 第一步 下载yum文件

```
进入mysql官网: https://dev.mysql.com/downloads/repo/yum/
选择对应的版本下载对应的文件 我是centos7 选择的就是Linux 7 / Oracle Linux 7
```

## 第二步 上传yum文件到Linux服务器

将文件上传到服务器上面，然后记住上传的位置。第一步和第二步可以在linux上通过wget 下载yum文件

## 第三步 设置源文件

```linux
[root@localhost mysql]# yum -y install mysql80-community-release-el7-6.noarch.rpm
```

## 第四步 耗时比较长

```linux
[root@localhost mysql]# yum -y install mysql-community-server
```

可能存在的问题：

```linux
获取 GPG 密钥失败：[Errno 14] curl#37 - "Couldn't open file /etc/pki/rpm-gpg/RPM-GPG-KEY-mysql-2022"
```

处理方式：

```linux
rpm --import https://repo.mysql.com/RPM-GPG-KEY-mysql-2022
```

## 第五步 查看配置文件，Mysql初始密码

安装完毕后，可以通过命令查看mysql的状态

```shell
systemctl status mysqld
```

启动mysql

```shell
systemctl start mysqld
```

启动之后你会发现你登录不上去，因为账号密码没有，需要通过配置文件找到日志文件，查看日志文件里面的信息。
通过yum安装的mysql默认配置文件路径地址： /etc/my.cnf 或者全局查找一下my.cnf文件
通过查看my.cnf文件可以看到mysql相关的存储文件路径，日志文件路径

```
# 数据目录
datadir=/var/lib/mysql
socket=/var/lib/mysql/mysql.sock
# 日志目录
log-error=/var/log/mysqld.log
pid-file=/var/run/mysqld/mysqld.pid
```

打开日志文件

```linux
less /var/log/mysqld.log
```

找到账号密码

```
2022-07-02T00:20:05.219927+08:00 6 [Note] [MY-010454] [Server] A temporary password is generated for root@localhost: O_ox8(CTnqT2
```

通常账号基本都是root 密码的话就是后面的字符串。

## 第六步 修改初始密码

mysql8.0是要求必须修改初始密码才能正常使用的，所以需要修改初始密码

```linux
mysql -uroot -p
#回车 然后输入上面的密码就可以进入到mysql了。
```

mysql8.0修改密码的方式和之前不一样了，新的修改方式

```linux
ALTER USER 'root'@'localhost' IDENTIFIED BY '新密码'; 
 # 注意事项 新密码需要包含大小写字母，特殊字符，数字，长度不能小于8位。
```

然后使用exit命令退出mysql ,重新使用新的密码登录即可。

## 第七步 设置密码策略(可选操作)

上面设置的密码很复杂，我不想设置这么复杂的密码，所以可以修改mysql的密码策略，可以在配置文件当中设置参数，也可以直接在mysql当中进行设置。
首先进入mysql

```linux
mysql -uroot -p
#回车 然后输入新密码就可以进入到mysql了。
```

在mysql界面进行操作 首先查看当前密码策略状态

```linux
SHOW VARIABLES LIKE 'validate_password%';
```

```linux
#密码验证策略低要求(LOW代表低级)
set global validate_password.policy=LOW;
#密码至少要包含的小写字母个数和大写字母个数
set global validate_password.mixed_case_count=0;
#密码至少要包含的数字个数。
set global validate_password.number_count=0; 
#密码至少要包含的特殊字符数
set global validate_password.special_char_count=0; 
#密码最小长度
set global validate_password.length=6;
```

设置完毕后再次查看就发现生效了。

## 第八步 创建新账号并授权

mysql 默认账号是root 并且限定只能通过本地访问，那么想通过网卡127.0.0.1访问或者远程访问就需要新建账号并授权。
创建账号

```linux
create user 'root'@'%' identified by '密码';
```

root 表示账号    % 表示远程连接 如果是具体ip表示只能具体ip链接 例如：127.0.0.1
给账号授权

```linux
grant all privileges on *.* to 'root'@'127.0.0.1' with grant option; 
 # 刷新权限
 flush privileges;
```

all privileges 表示全部权限
第一个*  表示数据库
第二个 * 表示数据表

## 第九步 配置防火墙或者直接关闭防火墙

```linux
# 查看防火墙状态  ，
systemctl status firewalld
# 关闭防火墙  如果不想启动，觉得麻烦到这里就可以结束了
systemctl stop firewalld
# 启动防火墙 如果要启动 ，按照下面的顺序进行即可
systemctl start firewalld
# 查看防火墙永久开放端口
firewall-cmd --list-ports --permanent
# 添加新的永久开放端口
firewall-cmd --add-port=3306/tcp --permanent
firewall-cmd --add-port=3306/udp --permanent
# 防火墙加载开放端口
 firewall-cmd --reload
 # 重启防火墙
 systemctl restart firewalld
```

## 第十步 云服务器（可选）

如果是云服务器那么还需要登录云服务器的控制面板，找到网络安全组，开通云服务器的端口。

## 最后一步 远程连接查看

找个数据库可视化工具，或者代码程序测试是否能够正常连接。

可能存在的问题：2059 - Authentication plugin "caching_sha2_password" cannot be loaded:...........

之前链接安装windows版本的时候出现过，链接安装的linux版本还未出现过这种情况。反正原因就是身份验证插件不对的问题，处理方式非常简单，将上面创建的账号的语句更换一下，重新创建个账号即可。

```linux
create user 'root'@'%' identified with mysql_native_password by '你的密码';
```

## 最后注意事项

1 当有需要修改配置文件的要求时，先关闭数据库，避免发生问题
2 当启动有问题时，可以查看日志文件
3 数据库数据目录请勿乱动

