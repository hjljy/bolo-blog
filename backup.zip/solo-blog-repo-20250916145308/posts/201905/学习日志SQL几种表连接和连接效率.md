title: 学习日志——SQL几种表连接和连接效率
date: '2019-05-30 23:54:03'
updated: '2019-05-30 23:54:03'
tags: [sql]
permalink: /articles/2019/05/30/1559231642979.html
---
![](https://img.hacpai.com/bing/20190222.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

##  学习原因
最近在进行一个数据展示的项目，问题是公司目前的情况是采集到了数据，将数据存入到了一个数据中心，然后就没有任何操作了。也就是说要从原始数据当中查询数据进行数据展示，这是一个很难受的过程，但是又是一个要必然经历的过程，因为原始数据来了之后，必然要通过实际的业务来检验数据的正确性，有效性和质量，然后就对应的业务数据进行清洗，提取存入业务库，方便以后的操作。然后后端代码基本上没怎么写，全部都思考查询sql应该怎么写了。
## 表连接
### 交叉连接查询（cross join）
多个表联合查询，这种方式如果不添加where条件的话会产生笛卡儿积  但是添加了where条件的话又相当于inner join 内连接
```
SELECT  * FROM  表A,表B  where  A.xx=B.xx
```
### 内连接（inner join ）
这种就相当于上面交叉连接添加了where条件。同时可以省略掉inner  ，只写join。 
内连接返回数据是条件相等的数据。也就是交集
```
SELECT  * FROM  表A  inner join  表B  on  A.xx=B.xx
```
### 外连接 （outer join）
外连接分为 left join 和right join。 
left join（左外连接）表示以左边的表为主表，无论ON后面的条件是否满足，都会返回左边的表的数据。
right join（右外连接）表示以右边的表为主表，无论ON后面的条件是否满足，都会返回右边的表的数据。
```
SELECT  * FROM  表A left  join  表B  on  A.xx=B.xx
SELECT  * FROM  表A right  join  表B  on  A.xx=B.xx
```
### 全连接（full join）
全连接（full join），返回的是全部的数据。
```
SELECT  * FROM  表A full  join  表B  on  A.xx=B.xx
```
 但是在mysql当中是不支持 full join的 需要通过左外连接+union + 右外连接实现。
## 连接效率问题
这个的话，在网上找了很多资料，也自己创建了很多的假数据进行验证，验证过程很简单就不记录了。
在同样的条件下
left join 和right join 效率是一样的。
同时：inner join  > outer join  > full join
## 相关资料

> [图解 SQL 中各种连接 JOIN](https://www.jianshu.com/p/fbf0c0f51861)
> [深入理解SQL的四种连接-左外连接、右外连接、内连接、全连接](https://www.cnblogs.com/yyjie/p/7788413.html)