title: JAVA使用JAVACV实现图片合成短视频，并给视频添加音频！！！
date: '2020-05-16 20:05:19'
updated: '2020-06-02 11:45:38'
tags: [javacv]
permalink: /articles/2020/05/16/1589630719478.html
---
![](https://img.hacpai.com/bing/20191117.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

玩抖音的时候，发现可以根据图片生成视频，并添加音频，同时刚好在项目当中也遇到需要利用多张图片生成视频的操作，特此记录下实现的过程！！！

JAVA来实现图片合成视频这个需求，想想还是非常少见的，在网上找了很久资料，基本只找到一个开源库：JAVACV 可以进行操作。并且在网上查找资料的时候也是发现，这方面的资料也是非常少的。有点难受哎！！！

## 什么是JAVACV？

> JavaCV 是一款开源的视觉处理库，基于Apache License Version 2.0协议和GPLv2两种协议 [1] ，对各种常用计算机视觉库封装后的一组jar包，封装了OpenCV、libdc1394、OpenKinect、videoInput和ARToolKitPlus等计算机视觉编程人员常用库的接口。
> JavaCV通过其中的utility类方便的在包括Android在内的Java平台上调用这些接口。

GITHUB项目地址：https://github.com/bytedeco/javacv
GITEE地址：https://gitee.com/hjljy/javacv   （非官方，自己fork的一份）
最重要的是这个项目现在还在维护当中：无论是GITHUB地址，还是Maven仓库，都可以看到代码或者JAR包近期有过更新！！！
Maven仓库地址：https://mvnrepository.com/search?q=javacv

## 相关JAR包

下载这个jar非常耗时。难受！！！ 建议切换到阿里云仓库，下载要快很多

```xml
<dependency>
            <groupId>org.bytedeco</groupId>
            <artifactId>javacv</artifactId>
            <version>1.5.2</version>
</dependency>
<dependency>
            <groupId>org.bytedeco</groupId>
            <artifactId>javacv-platform</artifactId>
            <version>1.5.2</version>
</dependency>
```

## 图片合成视频

视频都是一张一张图片组成的，每秒的视频都是由25张以上的图片组成的，这个在视频术语里面叫做帧！！！ 具体的合成代码如下：

```java
package cn.hjljy.javacv;

import org.bytedeco.ffmpeg.global.avcodec;
import org.bytedeco.ffmpeg.global.avutil;
import org.bytedeco.javacv.*;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * @author 海加尔金鹰 www.hjljy.cn
 * @version V1.0
 * @email hjljy@outlook.com
 * @description: 图片合成MP4
 * @since 2020/5/16 18:00
 **/
public class Image2Mp4 {
    public static void main(String[] args) throws Exception {
        //合成的MP4
        String mp4SavePath = "D:\\javacv\\mp4\\img.mp4";
        //图片地址 这里面放了22张图片
        String img = "D:\\javacv\\img";
        int width = 1600;
        int height = 900;
        //读取所有图片
        File file = new File(img);
        File[] files = file.listFiles();
        Map<Integer, File> imgMap = new HashMap<Integer, File>();
        int num = 0;
        for (File imgFile : files) {
            imgMap.put(num, imgFile);
            num++;
        }
        createMp4(mp4SavePath, imgMap, width, height);
    }

    private static void createMp4(String mp4SavePath, Map<Integer, File> imgMap, int width, int height) throws FrameRecorder.Exception {
        //视频宽高最好是按照常见的视频的宽高  16：9  或者 9：16
        FFmpegFrameRecorder recorder = new FFmpegFrameRecorder(mp4SavePath, width, height);
        //设置视频编码层模式
        recorder.setVideoCodec(avcodec.AV_CODEC_ID_H264);
        //设置视频为25帧每秒
        recorder.setFrameRate(25);
        //设置视频图像数据格式
        recorder.setPixelFormat(avutil.AV_PIX_FMT_YUV420P);
        recorder.setFormat("mp4");
        try {
            recorder.start();
            Java2DFrameConverter converter = new Java2DFrameConverter();
            //录制一个22秒的视频
            for (int i = 0; i < 22; i++) {
                BufferedImage read = ImageIO.read(imgMap.get(i));
                //一秒是25帧 所以要记录25次
                for (int j = 0; j < 25; j++) {
                    recorder.record(converter.getFrame(read));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //最后一定要结束并释放资源
            recorder.stop();
            recorder.release();
        }
    }
}
```

在合成完毕之后，正常打开可以看到一个22秒的视频，可以正常播放，里面的画面也是图片文件夹里面的图片。
几个需要注意的点：
1 建议合成的图片宽高要一致，并且视频的宽高还是要符合一定比例，不然会合成失败！！！
2 一定要释放资源，这个非常占内存
3 H264和YUV420P 都是视频的一些属性，具体作用百度一下你就知道。反正我不是很清楚！！！
4 合成完毕后，会打印合成信息，里面有合成的视频的详细信息，可以仔细看看！！！

## 视频融合音频

上面合成的视频没有声音，需要将音频融合到视频里面。形成一个完整的视频！！！

```java
public static boolean mergeAudioAndVideo(String videoPath, String audioPath, String outPut) throws Exception {
        boolean isCreated = true;
        File file = new File(videoPath);
        if (!file.exists()) {
            return false;
        }
        FrameRecorder recorder = null;
        FrameGrabber grabber1 = null;
        FrameGrabber grabber2 = null;
        try {
            //抓取视频帧
            grabber1 = new FFmpegFrameGrabber(videoPath);
            //抓取音频帧
            grabber2 = new FFmpegFrameGrabber(audioPath);
            grabber1.start();
            grabber2.start();
            //创建录制
            recorder = new FFmpegFrameRecorder(outPut,
                    grabber1.getImageWidth(), grabber1.getImageHeight(),
                    grabber2.getAudioChannels());

            recorder.setFormat("mp4");
            recorder.setFrameRate(grabber1.getFrameRate());
            recorder.setSampleRate(grabber2.getSampleRate());
            recorder.start();

            Frame frame1;
            Frame frame2 ;
            //先录入视频
            while ((frame1 = grabber1.grabFrame()) != null ){
                recorder.record(frame1);
            }
            //然后录入音频
            while ((frame2 = grabber2.grabFrame()) != null) {
                recorder.record(frame2);
            }
            grabber1.stop();
            grabber2.stop();
            recorder.stop();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (recorder != null) {
                    recorder.release();
                }
                if (grabber1 != null) {
                    grabber1.release();
                }
                if (grabber2 != null) {
                    grabber2.release();
                }
            } catch (FrameRecorder.Exception e) {
                e.printStackTrace();
            }
        }
        return isCreated;

    }
```

到这里一个完整的视频就合成出来了！！！。但是在视频融合音频的过程当中还是有一些比较需要注意的点：
1 视频长度和音频长度尽量保持一致，如果不一致，合成的视频长度会以最长的为准，音频短，后面就自然缺失音频，视频短，后面的视频会呈现视频的最后一帧。
2 不建议录一帧视频然后录一帧音频，音频的后半段会丢失，比例差不多是1：1.6！！！

## 最后总结

这个功能是非常耗时与耗内存的一个操作，所以一定要注意服务器的内存问题。
推荐一些其他人的操作文章：
[音频与视频合成技术](https://blog.csdn.net/xiaopy_0508/article/details/54962386)
[javaCV入门指南：序章](https://blog.csdn.net/eguid_1/article/details/82875343)
[javacv opencv 多图片合成视频 并加入mp3的音频 控制视频秒数](https://blog.csdn.net/boting/article/details/80886585)



我的博客即将同步至腾讯云+社区，邀请大家一同入驻：https://cloud.tencent.com/developer/support-plan?invite_code=2laihd59op440
