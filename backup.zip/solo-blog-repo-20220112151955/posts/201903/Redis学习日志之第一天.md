title: Redis学习日志之第一天
date: '2019-03-12 16:55:11'
updated: '2019-03-12 16:55:11'
tags: [redis]
permalink: /articles/2019/03/11/1552299085128.html
---
![](https://img.hacpai.com/bing/20171229.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

之前开发当中基本使用的是MySQL数据库，最近打算学习一下redis数据库，在此将自己学习的过程记录下来。
# redis简单说明
  redis的官方网站：https://redis.io/
  redis的前世今生：https://blog.csdn.net/echizao1839/article/details/80883312
  redis的简单说明：一个开源、支持网络、基于内存亦可持久化的日志型、Key-Value的NoSql数据库。
# redis在linux下的安装
安装基于阿里云服务器Centos7.0版本。
第一步：使用putty远程连接工具进入服务器（使用其他工具也行，反正就是进入到自己的阿里云服务器上）
第二步：依次输入以下命令，就安装完毕了。这是官网网站提供的安装教程，如果熟悉linux命令，可以自己在make命令后面添加参数，安装到指定位置。[官网安装教程。。。。在网页最下面](https://redis.io/download)
wget http://download.redis.io/releases/redis-5.0.3.tar.gz
tar xzf redis-5.0.3.tar.gz
cd redis-5.0.3
make
第三步：启动redis服务器，不推荐使用官方网站的方式，这种方式在关闭putty或者其他远程连接工具后，redis也会关闭。建议使用后台模式启动。在redis-5.0.3 目录下依次输入以下命令
 cd src
./redis-server &
第四步：在src目录下输入以下命令进入redis客户端进行数据的存入和读取  出现如下情况就表示redis数据库安装成功，可以正常存取数据。
![./redis-cli
set name 
get](https://img-blog.csdnimg.cn/20190311180900117.png)

备注：
1 可以通过ctrl+c退出客户端
2 上述启动方式是默认配置文件进行启动，可以在启动时指定自己的配置文件进行启动。
3 查看redis是否在运行： ps aux | grep redis
4 停止redis服务在安装目录src下面输入：./redis-cli shutdown
5 后台启动命令在安装目录src下面输入：./redis-server &

# redis的安全设置
设置redis的安全密码：在redis.conf中找到requirepass 进行修改
requirepass password    （这里的password就是密码，建议越长越好）   
修改之后重启redis  在启动redis时需要指定刚才的redis.conf，否则不生效。
然后进入redis-cli  
 ```
[root@localhost src]# ./redis-cli
127.0.0.1:6379> get myname
(error) NOAUTH Authentication required.
```
就无法获取到数据了，需要输入密码进行认证
```
127.0.0.1:6379> AUTH password
OK
127.0.0.1:6379> get myname
"ycf"
127.0.0.1:6379>
 ```
 最后就基本搞定了。接下来就是在项目当中的简单使用了。