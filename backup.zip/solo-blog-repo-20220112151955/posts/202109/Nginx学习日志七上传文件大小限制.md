title: Nginx学习日志（七）上传文件大小限制
date: '2021-09-22 15:37:29'
updated: '2021-09-22 16:31:58'
tags: [Nginx]
permalink: /articles/2021/09/22/1632296249085.html
---
![](https://b3logfile.com/bing/20201218.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

最近上传文件的时候，服务器出现了![image.png](https://image.hjljy.cn/2021/09-22/j2E_image.png) 很明显是nginx的一个限制。

处理方式：

根据文档说明添加参数然后重启即可   [nginx文档地址](https://www.nginx.cn/doc/standard/httpcore.html)

client_max_body_size 50M; 表示最大50M

```
 server {
        listen       80 default_server;
        server_name  www.hjljy.cn;
        client_max_body_size 50M;
        location / {
            return 301 https://www.hjljy.cn$request_uri;
        }
	}
```
