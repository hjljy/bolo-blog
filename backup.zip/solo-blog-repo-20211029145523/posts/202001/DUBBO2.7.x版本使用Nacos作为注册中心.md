title: DUBBO2.7.x版本使用Nacos作为注册中心
date: '2020-01-07 19:38:26'
updated: '2020-01-07 19:38:26'
tags: [dubbo, nacos, 微服务]
permalink: /articles/2020/01/07/1578397106684.html
---
![](https://img.hacpai.com/bing/20180420.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 前言

之前已经学习了 Spring boot + DUBBO2.7.4 +zookeeper 的整合： [springboot 整合 dubbo2.7.x 版本
](https://www.hjljy.cn/articles/2019/12/06/1575615333350.html)在注册中心的选择上，发现最近 nacos 的热度比较高，又要超越 zookeeper 的趋势，没有无缘无故的热度，肯定是有一些原因才会火起来的。所以打算学习下，了解下 nacos 的优劣，提升技术知识储备。

## 什么是 Nacos

> 一个更易于构建云原生应用的动态服务发现、配置管理和服务管理平台。

Nacos 官方网站：[https://nacos.io/zh-cn/](https://nacos.io/zh-cn/)     GitHub: [https://github.com/alibaba/nacos](https://github.com/alibaba/nacos)

有时 GitHub 下载较慢，就可以选择国内的 Gitee: [https://gitee.com/mirrors/Nacos?_from=gitee_search](https://gitee.com/mirrors/Nacos?_from=gitee_search)

下载后如何安装启动 nacos? 官网有详细介绍，这里就不描述了。

启动成功后会看到一条信息：

> INFO Tomcat started on port(s): 8848 (http) with context path '/nacos'

然后在浏览器输入：localhost:8848/nacos  输入默认密码(nacos)就可以进入 nacos 的管理界面
![](https://img.hacpai.com/file/2020/01/图片-c08c2841.png)

## DUBBO2.7.x 整合 Nacos

1. 在 IDEA 当中快速构建一个 SpringBoot 项目（nacos_demo），然后分别快速创建三个子 models:  nacos_api,nacos_service,nacos_customer 项目（都是 SpringBoot 项目）
2. 在 nacos_demo 当中引入 dubbo 和 nacos 的 jar 包 （注意事项：dubbo-registry-nacos 自动引入的 nacos-client jar 是 1.1.1 版本的。）

```
<!-- dubbo 2.7.x引入-->
        <dependency>
            <groupId>org.apache.dubbo</groupId>
            <artifactId>dubbo-spring-boot-starter</artifactId>
            <version>2.7.5</version>
        </dependency>
        <!-- nacos 2.7.x引入-->
        <dependency>
            <groupId>org.apache.dubbo</groupId>
            <artifactId>dubbo-registry-nacos</artifactId>
            <version>2.7.5</version>
        </dependency>
```

3. 在 nacos_service 和 nacos_customer 当中配置 dubbo 的相关配置

```
# Spring boot application
spring.application.name=dubbo-nacos-service
# Base packages to scan Dubbo Component: @org.apache.dubbo.config.annotation.Service
dubbo.scan.base-packages=cn.hjljy.springboot.dubbo_nacos_service.impl

# Dubbo Application
## The default value of dubbo.application.name is ${spring.application.name}
## dubbo.application.name=${spring.application.name}

# Dubbo Protocol
dubbo.protocol.name=dubbo
dubbo.protocol.port=12345

## Dubbo Registry
dubbo.registry.address=nacos://127.0.0.1:8848
```

4. 在 service 当中创建 dubbo 服务，并在 customer 当中进行调用（代码略！！！）
5. 最后在 nacos 管理界面查看相关的服务信息就可以了。

## 总结

完整代码地址：https://github.com/hjljy/dubbo_nacos_demo

入门非常简单，自带服务信息界面（可以在服务列表设置某个服务的权重，下线某个服务等等简单的操作）

吐槽：nacos 放在 GitHub 上面的，下载了好几次都没有下载成功，提示下载被禁止，最后还是自己 fock 的 gitee 上的源码自行编译的。