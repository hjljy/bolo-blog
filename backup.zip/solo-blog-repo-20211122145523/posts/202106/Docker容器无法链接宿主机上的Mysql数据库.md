title: Docker容器无法链接宿主机上的Mysql数据库
date: '2021-06-04 14:36:21'
updated: '2021-08-12 15:04:27'
tags: [bug, docker]
permalink: /articles/2021/06/04/1622788581523.html
---
![](https://b3logfile.com/bing/20200727.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

本来宿主机上存在一个mysql，然后在安装Nacos就准备使用mysql来进行数据存储，创建好数据库表结构，用户账号之后，使用如下命令，发现Nacos始终无法连接上宿主机上的mysql数据库，然后各种检查：例如检查账号权限，是否开启远程链接权限等等，但是就是docker启动就是链接不上mysql。

```shell
docker run -d --name nacos -e MODE=standalone -e MYSQL_SERVICE_HOST="127.0.0.1" -e MYSQL_DATABASE_NUM=1 -e SPRING_DATASOURCE_PLATFORM=mysql  -e MYSQL_SERVICE_USER=nacos -e MYSQL_SERVICE_PASSWORD=nacos -e MYSQL_SERVICE_DB_NAME="nacos"  -e JVM_XMS=128M -e JVM_XMX=256M -e JVM_XMN=128M -e NACOS_DEBUG=y  -p 8848:8848 --restart=always -v /home/nacos/logs:/home/nacos/logs nacos/nacos-server:2.0.1 
```

问题：最后发现是因为MYSQL_SERVICE_HOST="127.0.0.1" 的原因，这个127.0.0.1并不会指向宿主机，所以才会失败！！！
处理：在宿主机输入：ifconfig 找到 docker0的网卡地址，将127.0.0.1换成对应地址即可，通常是172.17.0.1或者172.18.0.1
