title: 记录——JAVA动态加载外部JAR，并调用方法以及卸载关闭打开的外部JAR
date: '2019-10-16 11:39:32'
updated: '2019-10-16 11:39:32'
tags: [JAR, JAVA]
permalink: /articles/2019/10/16/1571197172556.html
---
![](https://img.hacpai.com/bing/20190921.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 正文
最近在工作当中需要通过JAVA代码去调用外部JAR里面的方法，而不是直接在项目当中直接引入对应的JAR。记录一下实现过程当中遇到的问题和具体实现的代码。

# 具体代码实现
第一步：创建一个测试类,然后把这个类打包成一个普通的jar包。打包方法：   [ 记录——IDEA如何打普通JAR包](https://www.hjljy.cn/articles/2019/10/15/1571127445525.html)

```
public class MyTest {
    public void show(String name){
        System.out.println("参数是："+name);
    }
}
```
第二步：在其他项目当中调用刚才打包的jar里面的show方法
```
public class AddJar {

    public static void main(String[] args){
        //外部jar所在位置
        String path = "file:D:\\Program File\\IDEA\\WorkSpase\\Test20191015\\out\\artifacts\\test191015\\test191015.jar";
        URLClassLoader urlClassLoader =null;
        Class<?> MyTest = null;
        try {
            //通过URLClassLoader加载外部jar
            urlClassLoader = new URLClassLoader(new URL[]{new URL(path)});
            //获取外部jar里面的具体类对象
            MyTest = urlClassLoader.loadClass("cn.hjljy.MyTest");
            //创建对象实例
            Object instance = MyTest.newInstance();
            //获取实例当中的方法名为show，参数只有一个且类型为string的public方法
            Method method = MyTest.getMethod("show", String.class);
            //传入实例以及方法参数信息执行这个方法
            Object ada = method.invoke(instance, "ada");
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            //卸载关闭外部jar
            try {
                urlClassLoader.close();
            } catch (IOException e) {
                System.out.println("关闭外部jar失败："+e.getMessage());
            }
        }
    }
}
```
到这里就实现了对外部jar的加载和调用以及关闭。

# 注意事项
* 外部jar的路径需要用file开头
* loadClass是输入类所在的package路径
* 如果不调用urlClassLoader.close()这个方法关闭外部jar的话，外部jar会一直呈现占用状态。PS：这个方法是JDK1.7开始支持的。
* 上述方法是不能调用外部jar里面的mian方法的，代码中调用外部jar里面的main方法可以通过RunTime类执行 java -jar  xxx.jar命令进行调用。