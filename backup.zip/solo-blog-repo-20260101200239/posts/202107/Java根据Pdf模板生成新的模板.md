title: Java根据Pdf模板生成新的模板
date: '2021-07-22 15:52:44'
updated: '2021-07-22 17:10:40'
tags: [itext]
permalink: /articles/2021/07/22/1626940364152.html
---
![](https://b3logfile.com/bing/20190511.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

最近有需求要根据现有的PDF模板生成新的PDF出来，网上资料一大堆，主要总结下自己遇到的问题和代码

## 第一步 制作模板

1 通过Adobe Acrobat Pro 根据现有的PDF制作一个模板

2 通过[https://www.pdfescape.com/open/](https://www.pdfescape.com/open/) 网站，根据现有的PDF制作一个模板

## 第二步 引入POM

```xml
        <dependency>
            <groupId>com.itextpdf</groupId>
            <artifactId>itextpdf</artifactId>
            <version>5.5.13</version>
        </dependency>
        <dependency>
            <groupId>com.itextpdf</groupId>
            <artifactId>itext-asian</artifactId>
            <version>5.2.0</version>
        </dependency>
```

## 第三步 根据模板生成PDF

```
    public static byte[] createPdfByTemp(Map<String, String> data) {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            // pdf模板所在路径，就是网站制作好后下载的pdf模板路径
            Resource resource = new ClassPathResource(tempPath);
            InputStream is = resource.getInputStream();
            PdfReader reader = new PdfReader(is);
            PdfStamper ps = new PdfStamper(reader, bos);
            // 使用中文字体
            BaseFont bf = BaseFont.createFont("STSong-Light", "UniGB-UCS2-H", BaseFont.EMBEDDED);
            ArrayList<BaseFont> fontList = new ArrayList<>();
            fontList.add(bf);


            AcroFields fields = ps.getAcroFields();
            fields.setSubstitutionFonts(fontList);

            fillData(fields, data, ps);

            //必须要调用这个，否则文档不会生成的
            ps.setFormFlattening(true);
            ps.close();

            return bos.toByteArray();

        } catch (Exception e) {
            log.error("生成pdf文件失败：" + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                bos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        throw new MonitorException(SysCodeEnum.USER_FILE_ERROR, "生成pdf文件失败，请稍后再试");
    }
```

最近有需求要根据现有的PDF模板生成新的PDF出来，网上资料一大堆，主要总结下自己遇到的问题和代码

## 第一步 制作模板

1 通过Adobe Acrobat Pro 根据现有的PDF制作一个模板

2 通过[https://www.pdfescape.com/open/](https://www.pdfescape.com/open/) 网站，根据现有的PDF制作一个模板

## 第二步 引入POM

```xml
        <dependency>
            <groupId>com.itextpdf</groupId>
            <artifactId>itextpdf</artifactId>
            <version>5.5.13</version>
        </dependency>
        <dependency>
            <groupId>com.itextpdf</groupId>
            <artifactId>itext-asian</artifactId>
            <version>5.2.0</version>
        </dependency>
```

## 第三步 根据模板生成PDF

下面是快捷demo代码，来源于网上资料：[JAVA使用itext根据模板生成PDF文档](https://www.cnblogs.com/pxblog/p/13261187.html)

```java
 package com.pdf;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.lowagie.text.pdf.AcroFields;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfStamper;

public class Test {
    public static void main(String[] args) throws Exception {
        export();
        System.out.println("生成完成");
    }

    public static void export(){
        try {
            // pdf模板所在路径，就是网站制作好后下载的pdf模板路径
            String fileName = "D:/testpdf.pdf";
            PdfReader reader = new PdfReader(fileName);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            PdfStamper ps = new PdfStamper(reader, bos);

            // 使用中文字体
            BaseFont bf = BaseFont.createFont("STSong-Light", "UniGB-UCS2-H", BaseFont.NOT_EMBEDDED);
            ArrayList<BaseFont> fontList = new ArrayList<BaseFont>();
            fontList.add(bf);


            AcroFields fields = ps.getAcroFields();
            fields.setSubstitutionFonts(fontList);
            fillData(fields, data());

            //必须要调用这个，否则文档不会生成的
            ps.setFormFlattening(true);
            ps.close();

            //生成pdf路径存放的路径
            OutputStream fos = new FileOutputStream("D:/result.pdf");
            fos.write(bos.toByteArray());
            fos.flush();
            fos.close();
            bos.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    /**
     * 填充模板中的数据
     */
    public static void fillData(AcroFields fields, Map<String, String> data) {
        try {
            for (String key : data.keySet()) {
                String value = data.get(key);
                // 为字段赋值,注意字段名称是区分大小写的
                fields.setField(key, value);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 填充数据源
     * 其中data存放的key值与pdf模板中的文本域值相对应
     */
    public static Map<String, String> data() {
        Map<String, String> data = new HashMap<String, String>();
        data.put("schoolName", "国际测试测试\r\n测试测试");
        data.put("userName", "yvioo");
        data.put("date", "2020/7");
        return data;
    }
}
  
```

### 如何填充图片数据

```csharp
    public static void fillImage(AcroFields fields, Map<String, String> imagesData, PdfStamper ps) throws IOException, DocumentException {
        for(String key : imagesData.keySet()) {
            String value = imagesData.get(key);
            //获取到当前图片字段对应的模板的页面
            int pageNo = fields.getFieldPositions(key).get(0).page;
            //获取到当前图片字段对应的模板的位置
            Rectangle signRect = fields.getFieldPositions(key).get(0).position;
            float x = signRect.getLeft();
            float y = signRect.getBottom();
            //根据路径读取图片
            Image image = Image.getInstance(value);
            //获取图片页面
            PdfContentByte pdfContentByte = ps.getOverContent(pageNo);
            //图片大小自适应
            image.scaleToFit(signRect.getWidth(), signRect.getHeight());
            //添加图片
            image.setAbsolutePosition(x, y);
            pdfContentByte.addImage(image);
        }
    }
```

### 如何让填充的数据进行换行

```java
    public static void fillChunkData(AcroFields fields, Map<String, String> data, PdfStamper ps) throws IOException, DocumentException {
        // 为字段赋值,注意字段名称是区分大小写的
        for (String key : data.keySet()) {
            //获取到当前图片字段对应的模板的页面
            int page = fields.getFieldPositions(key).get(0).page;
            //获取到当前图片字段对应的模板的位置
            Rectangle rectangle = fields.getFieldPositions(key).get(0).position;
            float left = rectangle.getLeft();
            float right = rectangle.getRight();
            float top = rectangle.getTop();
            float bottom = rectangle.getBottom();
            //设置中文字体
            BaseFont baseFont = BaseFont.createFont("STSong-Light", "UniGB-UCS2-H", false);
            //设置字体大小，样式
            Font font = new Font(baseFont, 10, Font.NORMAL);
            PdfContentByte pdfContentByte = ps.getOverContent(page);
            //设置填充字段内容，位置
            ColumnText columnText = new ColumnText(pdfContentByte);
            Rectangle r = new Rectangle(left, bottom, right, top);
            columnText.setSimpleColumn(r);

            //对数据进行分割
            String checkInfo = data.get(key);
            String[] info = checkInfo.split("\\|");
            if (info.length == 2) {
                //填充该字段第一行数据
                Chunk chunk = new Chunk("第一行数据");
                Paragraph paragraph = new Paragraph(12, chunk);
                paragraph.setSpacingBefore(8);
                columnText.addText(paragraph);
                paragraph.setFont(font);
                //设置内容靠右
                //paragraph.setAlignment(Element.ALIGN_RIGHT);
                columnText.addElement(paragraph);
                Chunk chunk2 = new Chunk("第二行数据");
                Paragraph paragraph2 = new Paragraph(12, chunk2);
                paragraph2.setSpacingBefore(8);
                columnText.addText(paragraph2);
                paragraph2.setFont(font);
                columnText.addElement(paragraph2);
            }

            columnText.go();
        }
    }

```

## 总结

上手还是很容易的，主要是一些特殊操作，例如换行，靠右，字体颜色，大小等等样式相关的问题，毕竟需要生成完毕才能看到效果。
注意事项：
1 中文的支持需要引入itext-asian相关jar包
